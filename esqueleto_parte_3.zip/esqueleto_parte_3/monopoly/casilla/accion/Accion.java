package monopoly.casilla.accion;

import monopoly.Tablero;
import monopoly.casilla.Casilla;
import partida.Jugador;

import java.util.ArrayList;

public abstract class Accion extends Casilla {

    /* Constructor para casillas Suerte, Comunidad y Especiales:
     * Inicializa nombre, tipo, posición, dueño y tablero */
    public Accion(String nombre, String tipo, int posicion, Tablero tablero) {
        super(nombre, posicion,tipo, tablero);
    }

}
