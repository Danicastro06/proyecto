package monopoly.casilla.accion;

import monopoly.Tablero;
import partida.Jugador;

import java.util.ArrayList;

public class CajaComunidad extends Accion{


    public CajaComunidad(String nombre, String tipo, int posicion, Tablero tablero) {
        super(nombre, tipo, posicion, tablero);
    }
    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada) {
        this.sumarEstancia();

        return true;
    }
}
