package monopoly.casilla.accion;

import monopoly.Tablero;
import partida.*;
import static monopoly.Juego.consola;

import java.util.ArrayList;

public class Parking extends Accion {

    float valor;

    public Parking(String nombre, String tipo, int posicion, Tablero tablero) {
        super(nombre, tipo, posicion, tablero);
        this.valor = 0f; // Inicializa el valor del bote a 0
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada) {

        this.sumarEstancia();

        if (this.getNombre().equalsIgnoreCase("parking")) {
            if (this.getValor() > 0) {
                consola.imprimir(actual.getNombre() + " recibe " + (int) this.getValor() + "€ del bote de Parking.");
                actual.recibir(this.getValor());
                actual.setPremios(getValor());
                this.setValor(0);  // Reiniciar bote
            } else {
                consola.imprimir("El bote de Parking está vacío.");
            }
        }
        return true;
    }

    public float getValor() {
        return valor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    //
    public void sumarValor(float suma) {
        if (suma > 0) {
            this.valor += suma;
            consola.imprimir("El valor de " + this.getNombre() + " ha aumentado en " + (int) suma + "€. Total actual: " + (int) this.valor + "€.");
        }
    }
}