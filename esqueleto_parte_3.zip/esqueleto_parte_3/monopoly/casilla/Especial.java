package monopoly.casilla;
import partida.*;
import monopoly.Tablero;
import static monopoly.Juego.consola;

public class Especial extends Casilla {

    public Especial(String nombre,String tipo, int posicion, Tablero tablero) {
        super(nombre, posicion,tipo, tablero);
    }

    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada) {

        this.sumarEstancia();

        if (this.getNombre().equalsIgnoreCase("carcel")) {
            //No hace nada aun
            return true;
        } else if (this.getNombre().equalsIgnoreCase("salida")) {
            return true;
        } else if (this.getNombre().equalsIgnoreCase("ircarcel")) {
            Casilla carcel = getTablero().encontrar_casilla("Carcel");
            if (carcel != null) {
                actual.getAvatar().setLugar(carcel);
                carcel.sumarEstancia();
                actual.setEnCarcel(true);
                consola.imprimir(actual.getNombre() + " ha sido enviado a la Cárcel.");
                actual.setVecesEnCarcel();
            }
            return true;
        } else {
            return true; // Por defecto, evita error de return
        }
    }
}

