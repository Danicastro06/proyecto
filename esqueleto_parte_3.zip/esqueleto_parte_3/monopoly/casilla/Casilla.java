package monopoly.casilla;

import monopoly.edificios.Edificio;
import monopoly.casilla.Grupo;
import monopoly.Tablero;
import partida.*;
import java.util.ArrayList;

public abstract class Casilla {

    // Atributos de la casilla
    /*private String nombre; // Nombre de la casilla
    private String tipo; // Tipo de casilla: Solar, Especial, Transporte, Servicios, Comunidad, Suerte o Impuesto
    private float valor; // Valor de compra o bote (en Parking)
    private int posicion; // Posición de la casilla en el tablero (1-40)
    private Jugador duenho; // Dueño actual de la casilla (por defecto la banca)
    private Grupo grupo; // Grupo al que pertenece la casilla (solo aplica a solares)
    private float impuesto; // Cantidad a pagar al caer (alquiler o impuestos)
    private float hipoteca; // Valor otorgado si se hipoteca la casilla
    private ArrayList<Avatar> avatares; // Avatares actualmente en la casilla
    private Tablero tablero; // Tablero al que pertenece la casilla
    private ArrayList<Edificio> edificios;
    private int estancias;*/

    private String nombre; // Nombre de la casilla
    private int posicion; // Posición de la casilla en el tablero (1-40)
    private String tipo; // Tipo de casilla: Solar, Especial, Transporte, Servicios, Comunidad, Suerte o Impuesto
    private Tablero tablero; // Tablero al que pertenece la casilla
    private ArrayList<Avatar> avatares; // Avatares actualmente en la casilla
    private int estancias;


    // Constructor vacío
    public Casilla() {
    }

    public Casilla(String nombre, int posicion,String tipo, Tablero tablero) {
        this.nombre = nombre;
        this.posicion = posicion;
        this.tipo = tipo;
        this.tablero = tablero;
        this.avatares = new ArrayList<>();
        this.estancias = 0;
    }

    // Añade un avatar a la casilla
    public void anhadirAvatar(Avatar av) {
        if (av != null && !avatares.contains(av)) {
            avatares.add(av);
        }
    }

    public boolean estaAvatar(Avatar avatar) {
        if (avatar == null) {
            return false;
        }
        if (this.avatares == null) {
            return false;
        }
        return this.avatares.contains(avatar);
    }

    // Elimina un avatar de la casilla
    public void eliminarAvatar(Avatar av) {
        avatares.remove(av);
    }

    /* Evalúa qué sucede al caer en la casilla:
     * Devuelve true si el jugador puede cumplir sus pagos, false si entra en bancarrota */
    public abstract boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada);


    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public Tablero getTablero() {
        return tablero;
    }

    public int getPosicion() {
        return posicion;
    }

    public ArrayList<Avatar> getAvatares() {
        return avatares;
    }

    public int getEstancias(){
        return estancias;
    }

    public void sumarEstancia(){
        this.estancias++;
    }

}
