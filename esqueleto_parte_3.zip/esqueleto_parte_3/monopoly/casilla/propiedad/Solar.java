package monopoly.casilla.propiedad;
import monopoly.Tablero;
import monopoly.casilla.Grupo;
import monopoly.edificios.Edificio;
import partida.*;

import java.util.ArrayList;

public class Solar extends Propiedad {

    private float hipoteca; // Valor otorgado si se hipoteca la casilla
    private Grupo grupo; // Grupo al que pertenece la casilla (solo aplica a solares)
    private ArrayList<Edificio> edificios;


    /* Constructor para casillas tipo Solar*/
    public Solar(String nombre, String tipo, int posicion, float valor, Jugador duenho, Tablero tablero) {
        super(nombre,tipo, posicion,valor,duenho, tablero);
        this.hipoteca = 0f;
        this.grupo = null; // Se puede asignar después
        this.edificios = new ArrayList<>();
    }

    @Override
    public boolean evaluarCasilla(Jugador actual, Jugador banca, int tirada) {

        this.sumarEstancia();

        if (this.getDuenho() == null || this.getDuenho() == banca) {
            System.out.println("La casilla " + this.getNombre() + " está libre.");
            return true;
        }
        else if(this.getDuenho() != actual) {
            if (this.estaHipotecada()) {
                System.out.println("La casilla " + this.getDuenho() + " está hipotecada. No se paga alquiler.");
                return true;
            }
            float alquiler = this.calcularAlquiler();
            if (actual.puedePagar(alquiler)) {
                actual.pagar(alquiler, this.getDuenho());
                actual.setPagoDeAlquileres(alquiler);
                this.getDuenho().setCobroDeAlquileres(alquiler);
                System.out.println("El jugador " + actual.getNombre() + " ha pagado " + (int) alquiler + "€ de alquiler a " + this.getDuenho().getNombre() + ".");
                return true;
            } else {
                actual.declararBancarrota(this.getDuenho());
                System.out.println("El jugador " + actual.getNombre() + " no puede pagar el alquiler y ha sido declarado en bancarrota.");
                return false;
            }
        }
        else{
            return true;
        }
    }

    public Grupo getGrupo() {
        return grupo;
    }

    public float getHipoteca() {
        return hipoteca;
    }

    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    // Devuelve si la casilla está hipotecada
    public boolean estaHipotecada() {
        return this.hipoteca > 0;
    }

    public void setHipoteca(float hipoteca) {
        this.hipoteca = hipoteca;
    }
    public void setHipotecaAuto() {
        if (this.getNombre() == null) return;
        if (this.getTipo().equals("Solar")){
            this.hipoteca = this.getValor() / 2f;
        }
    }

    public float calcularAlquiler(){
        float alquiler = this.getImpuesto();
        for(Edificio ed : this.edificios){
            alquiler = alquiler + ed.getAlquiler();
        }
        return alquiler;
    }

    public ArrayList<Edificio> getEdificios() {
        if (this.edificios == null) this.edificios = new ArrayList<>();
        return new ArrayList<>(this.edificios); // devolver copia para encapsular
    }

    public int contarEdificiosTipo(String tipo) {
        if (this.edificios == null || tipo == null) return 0;
        int cont = 0;
        for (Edificio ed : this.edificios) {
            if (ed != null && tipo.equalsIgnoreCase(ed.getTipo())) cont++;
        }
        return cont;
    }

    public int getNumCasas() {
        return contarEdificiosTipo("casa");
    }

    public int getNumHoteles() {
        return contarEdificiosTipo("hotel");
    }

    public int getNumPiscinas() {
        return contarEdificiosTipo("piscina");
    }

    public int getNumPistas() {
        return contarEdificiosTipo("pista");
    }

    public void setEdificio(Edificio e) {
        if (e == null) return;
        if (this.edificios == null) this.edificios = new ArrayList<>();
        this.edificios.add(e);
        // Enlazar objeto Edificio con esta casilla y, si hace sentido, con el dueño actual
        try {
            e.setCasilla(this);
        } catch (Throwable ignored) {}
        try {
            if (e.getPropietario() == null && this.getDuenho() != null) e.setPropietario(this.getDuenho());
        } catch (Throwable ignored) {}
    }

    public boolean setNumCasas(int numCasas) {
        if (this.edificios == null) return false;
        int actuales = getNumCasas();
        if (numCasas >= actuales || numCasas < 0){
            System.out.println("Número de casas a quitar inválido.");
            return false;
        }
        int aEliminar = actuales - numCasas;
        java.util.Iterator<Edificio> it = edificios.iterator();
        while (it.hasNext() && aEliminar > 0) {
            Edificio ed = it.next();
            if (ed != null && "casa".equalsIgnoreCase(ed.getTipo())) {
                it.remove();
                aEliminar--;
            }
        }
        return true;
    }

    public void eliminarHotel() {
        if (this.edificios == null) return;

        java.util.Iterator<Edificio> it = edificios.iterator();
        while (it.hasNext()) {
            Edificio ed = it.next();
            if (ed != null && "hotel".equalsIgnoreCase(ed.getTipo())) {
                it.remove();
                break; // Elimina solo un hotel ya que no puede haber mas de uno
            }
        }
    }

    public void eliminarPiscina() {
        if (this.edificios == null) return;

        java.util.Iterator<Edificio> it = edificios.iterator();
        while (it.hasNext()) {
            Edificio ed = it.next();
            if (ed != null && "piscina".equalsIgnoreCase(ed.getTipo())) {
                it.remove();
                break; // Elimina solo una piscina ya que no puede haber mas de uno
            }
        }
    }

    public void eliminarPista() {
        if (this.edificios == null) return;
        java.util.Iterator<Edificio> it = edificios.iterator();
        while (it.hasNext()) {
            Edificio ed = it.next();
            if (ed != null && "pista".equalsIgnoreCase(ed.getTipo())) {
                it.remove();
                break; // Elimina solo una pista ya que no puede haber mas de uno
            }
        }
    }


    @Override
    public boolean alquiler() {
        // Una solar genera alquiler si tiene dueño y no está hipotecada
        return this.getDuenho() != null && !this.estaHipotecada();
    }

    @Override
    public float valor() {
        float total = this.getValor();
        if (this.edificios != null) {
            for (Edificio ed : this.edificios) {
                if (ed != null) {
                    total += ed.getCoste();
                }
            }
        }
        return total;
    }
}




