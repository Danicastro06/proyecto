package monopoly.casilla.propiedad;

import monopoly.Tablero;
import monopoly.casilla.Casilla;
import monopoly.casilla.Grupo;
import monopoly.edificios.Edificio;
import partida.Jugador;

import java.util.ArrayList;

public abstract class Propiedad extends Casilla {

    private Jugador duenho; // Dueño actual de la casilla (por defecto la banca)
    private float valor; // Valor de compra o bote (en Parking)
    private float impuesto; // Cantidad a pagar al caer (alquiler o impuestos)


    /* Constructor para casillas tipo Solar, Servicios o Transporte:
     * Inicializa nombre, tipo, posición, valor, dueño y tablero */
    public Propiedad(String nombre, String tipo, int posicion, float valor, Jugador duenho, Tablero tablero) {
        super(nombre, posicion,tipo, tablero);
        this.valor = valor;
        this.duenho = duenho;
        this.impuesto = 0;
    }


    /* Método para comprar la casilla:
     * Devuelve 0 si se compra correctamente, 1 si no es posible */
    public int comprarCasilla(Jugador solicitante, Jugador banca) {
        if (solicitante == null || banca == null) return 1;

        if (this.duenho != null && this.duenho != banca) {
            System.out.println("La casilla ya tiene dueño.");
            return 1;
        }

        if (solicitante.getFortuna() < this.valor) {
            System.out.println("Fondos insuficientes.");
            return 1;
        }

        solicitante.setFortuna(solicitante.getFortuna() - this.valor);
        this.duenho = solicitante;
        solicitante.anhadirPropiedad(this);
        solicitante.setDineroInvertido(valor);
        return 0;
    }

    boolean perteneceAJugador(Jugador jugador){
        if(this.duenho.equals(jugador)) return true;
        return false;
    }

    abstract boolean alquiler ();

    abstract float valor ();

    public float getValor() {
        return valor;
    }

    public Jugador getDuenho() {
        return duenho;
    }

    public float getImpuesto() {
        return impuesto;
    }

    public void setDuenho(Jugador duenho) {
        this.duenho = duenho;
    }

    public void setImpuesto(float impuesto) {
        this.impuesto = impuesto;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    // Añadir valor a la casilla (útil para Parking o solares no compradas)
    public void sumarValor(float suma) {
        if (suma > 0) {
            this.valor += suma;
            System.out.println("El valor de " + this.getNombre() + " ha aumentado en " + (int) suma + "€. Total actual: " + (int) this.valor + "€.");
        }
    }

}
