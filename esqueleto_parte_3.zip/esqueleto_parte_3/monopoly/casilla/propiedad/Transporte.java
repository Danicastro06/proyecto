package monopoly.casilla.propiedad;
import monopoly.Tablero;
import partida.*;

public class Transporte  extends Propiedad {

    public Transporte(String nombre, String tipo, int posicion, float valor, Jugador duenho, Tablero tablero) {
        super(nombre,tipo, posicion,valor,duenho, tablero);
    }

    @Override
    public boolean evaluarCasilla (Jugador actual, Jugador banca, int tirada) {

        this.sumarEstancia();

        if (this.getDuenho() == null || this.getDuenho() == banca) {
            System.out.println("La casilla " + this.getNombre() + " está libre.");
            return true;
        } else if (this.getDuenho() != actual) {
            float alquiler = 0;
            int transportes = 0;
            try {
                transportes = getDuenho().contarTransportes();
            } catch (Throwable ignored) {
            }
            if (transportes == 1) alquiler = 250000f;
            else if (transportes == 2) alquiler = 500000f;
            else if (transportes == 3) alquiler = 750000f;
            else alquiler = this.getImpuesto();
            if (actual.puedePagar(alquiler)) {
                actual.pagar(alquiler, this.getDuenho());
                System.out.println("El jugador " + actual.getNombre() + " ha pagado " + (int) alquiler + "€ de alquiler a " + this.getDuenho().getNombre() + ".");
                return true;
            } else {
                actual.declararBancarrota(this.getDuenho());
                System.out.println("El jugador " + actual.getNombre() + " no puede pagar el alquiler y ha sido declarado en bancarrota.");
                return false;
            }
        }
        else{
            return true;
        }
    }

    @Override
    public boolean alquiler() {
        return this.getDuenho() != null;
    }

    @Override
    public float valor() {
        return this.getValor();
    }
}
