package monopoly.casilla;
import monopoly.Tablero;
import monopoly.casilla.accion.Parking;
import partida.*;
import static monopoly.Juego.consola;

import java.util.ArrayList;

public class Impuesto extends Casilla {

    private float impuesto;
    /* Constructor para casillas de tipo IMPUESTOS:
     * Inicializa nombre, posición, impuesto, dueño y tablero */
    public Impuesto(String nombre, int posicion,String tipo, float impuesto, Tablero tablero) {
        super(nombre, posicion,tipo, tablero);
        this.impuesto = impuesto;
    }

    @Override
    public boolean evaluarCasilla(Jugador actual,Jugador banca, int tirada) {

        this.sumarEstancia();

        float impuesto = this.impuesto > 0 ? this.impuesto : 2000000f;
        if (actual.puedePagar(impuesto)) {
            actual.pagar(impuesto, banca);
            actual.setPagoDeTasasEImpuestos(impuesto);

            consola.imprimir("El jugador " + actual.getNombre() + " ha pagado " + (int) impuesto + "€ de impuesto.");
            Casilla parkin = getTablero().encontrar_casilla("Parking");
            Parking parking = (Parking) parkin;
            if (parking != null) parking.sumarValor(impuesto);
            return true;
        } else {
            consola.imprimir("El jugador " + actual.getNombre() + " no puede pagar el impuesto y ha sido declarado en bancarrota.");
            actual.declararBancarrota(banca);
            return false;
        }
    }

    public float getImpuesto() {
        return impuesto;
    }
    public void setImpuesto(float impuesto) {
        this.impuesto = impuesto;
    }
}
