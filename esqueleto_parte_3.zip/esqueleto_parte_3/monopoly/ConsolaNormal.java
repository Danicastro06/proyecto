package monopoly;

import java.util.Scanner;

public class ConsolaNormal implements Consola {

    @Override
    public String leer(String mensaje) {
        System.out.println(mensaje);
        Scanner sc = new Scanner(System.in);
        String linea = sc.nextLine();
        return linea;
    }

    @Override
    public void imprimir(String mensaje) {
        System.out.println(mensaje);
    }
}
