package monopoly.cartas;

import partida.*;
import monopoly.*;
import static monopoly.Juego.consola;
import monopoly.casilla.Casilla;

import java.util.ArrayList;



public class CajaComunidad extends Carta{



    public CajaComunidad() {
    }

    public void accion(Jugador jugador, Jugador banca,int contadorComunidad, ArrayList<Jugador> jugadores) {
        if (jugador == null) {
            consola.imprimir("Error: jugador no encontrado.");
            return;
        }
        int idCartaComunidad;
        Avatar avatar = jugador.getAvatar();
        Tablero tablero = avatar.getLugar().getTablero();
        idCartaComunidad = contadorComunidad;
        System.out.print(jugador.getNombre() + ", elige una carta: " + idCartaComunidad + ". Acción: ");
        switch (idCartaComunidad) {
            case 1:
                consola.imprimir("Paga 500.000€ por un fin de semana en un balneario de 5 estrellas.");
                jugador.pagarBanca(500000f);
                jugador.setPagoDeTasasEImpuestos(500000f);
                break;
            case 2:
                consola.imprimir("El jugador " + jugador.getNombre() + " es investigado por fraude de identidad. Va a la cárcel.");
                Casilla ircarcel = tablero.encontrar_casilla("IrCarcel");
                avatar.setLugar(ircarcel);
                avatar.getLugar().evaluarCasilla(jugador, banca, 0);
                break;
            case 3:
                Casilla salida = tablero.encontrar_casilla("Salida");
                avatar.setLugar(salida);
                avatar.getLugar().evaluarCasilla(jugador, banca, 0);
                jugador.recibir(Valor.SUMA_VUELTA);
                jugador.sumarVueltas();
                consola.imprimir(jugador.getNombre() + " ha ido a la casilla de Salida y recibe " + (int) Valor.SUMA_VUELTA + "€.");
                break;
            case 4:
                consola.imprimir("Devolución de Hacienda. Cobra 500.000€.");
                jugador.recibir(500000f);
                jugador.setPremios(500000f);
                break;
            case 5:
                consola.imprimir("Retrocede hasta Solar1 para comprar antigüedades exóticas.");
                Casilla solar1 = tablero.encontrar_casilla("Solar1");
                avatar.setLugar(solar1);
                avatar.getLugar().evaluarCasilla(jugador, banca, 0);
                break;
            case 6:
                consola.imprimir("Ve a Solar20 para disfrutar del San Fermín.");
                Casilla solar20 = tablero.encontrar_casilla("Solar20");
                Casilla c1 = avatar.getLugar();
                avatar.setLugar(solar20);
                avatar.getLugar().evaluarCasilla(jugador, banca, 0);
                if (c1.getPosicion() > solar20.getPosicion()) {
                    jugador.recibir(Valor.SUMA_VUELTA);
                    consola.imprimir(jugador.getNombre() + " ha pasado por Salida y recibe " + (int) Valor.SUMA_VUELTA + "€.");
                }
                break;
        }
    }
}
