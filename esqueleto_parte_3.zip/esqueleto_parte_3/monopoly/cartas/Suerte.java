package monopoly.cartas;
import java.util.ArrayList;
import partida.*;
import monopoly.*;
import monopoly.casilla.Casilla;
import monopoly.casilla.propiedad.Transporte;
import static monopoly.Juego.consola;

public class Suerte extends Carta{


    public Suerte(){

    }

    public void accion(Jugador jugador, Jugador banca, int contadorSuerte ,ArrayList<Jugador> jugadores) {
        if (jugador == null) {
            consola.imprimir("Error: jugador no encontrado.");
            return;
        }
        int idCartaSuerte;
        Avatar avatar = jugador.getAvatar();
        Tablero tablero = avatar.getLugar().getTablero();
        idCartaSuerte= contadorSuerte;
        System.out.print(jugador.getNombre() + ", elige una carta: " + idCartaSuerte + ". Acción: ");
        switch(idCartaSuerte){
                case 1:
                    consola.imprimir("El jugador avanza hasta la casilla Solar19 para hacer un viaje de placer.");
                    Casilla c = tablero.encontrar_casilla("Solar19");
                    Casilla c1 = avatar.getLugar();
                    avatar.setLugar(c);
                     avatar.getLugar().evaluarCasilla(jugador,banca,0);
                    if(c1.getPosicion()>c.getPosicion()){
                    jugador.recibir(Valor.SUMA_VUELTA);
                    jugador.sumarVueltas();
                    consola.imprimir(jugador.getNombre() + " ha pasado por Salida y recibe " + (int)Valor.SUMA_VUELTA + "€.");
                }
                break;
                case 2:
                    consola.imprimir("El jugador " + jugador.getNombre() + "es perseguido por impagos. Va a la cárcel.");
                    Casilla ircarcel = tablero.encontrar_casilla("IrCarcel");
                    avatar.setLugar(ircarcel);
                    avatar.getLugar().evaluarCasilla(jugador,banca,0);
                    break;
                case 3:
                    jugador.recibir(1000000f);
                    jugador.setPremios(1000000f);
                    consola.imprimir("¡El jugador: " + jugador.getNombre()+ " ha ganado el bote de la lotería! Recibe 1.000.000€.");
                    break;
                case 4:
                    consola.imprimir("Has sido elegido presidente de la junta directiva. Paga a cada jugador 250.000€.");
                    for (Jugador j: jugadores){
                        if(jugador.getNombre()!=j.getNombre()){
                            jugador.pagar(250000f,j);
                            jugador.setPagoDeTasasEImpuestos(250000f);
                            consola.imprimir("El jugador: " + jugador.getNombre()+ " paga 250.000€ a " + j.getNombre() +".");
                        }
                    }
                    break;
                case 5:
                    consola.imprimir("El jugador retrocede 3 casillas.");
                    Casilla actual = avatar.getLugar();
                    int posicion = actual.getPosicion();
                    Casilla nueva = tablero.encontrar_casilla_posicion(posicion - 3);
                    avatar.setLugar(nueva);
                    avatar.getLugar().evaluarCasilla(jugador,banca,0);
                    break;
                case 6:
                    consola.imprimir("Te multan por usar el móvil mientras conduces. Paga 150.000€.");
                    jugador.pagarBanca(150000f);
                    jugador.setPagoDeTasasEImpuestos(1500000f);
                    break;
                case 7:
                    consola.imprimir("Avanzas hasta la casilla de transporte más cercana. Si no tiene dueño, puedes comprarla sino pagas el doble de la operacion indicada");
                    Casilla lugarActual = avatar.getLugar();
                    int posActual = lugarActual.getPosicion();
                    java.util.List<Casilla> todas = tablero.getTodasCasillas();
                    int totalcasillas= (todas != null) ? todas.size() : 40;
                    Transporte destino = null;

                    for (int i = 1; i <= totalcasillas; i++) {
                        int nuevaPos = (posActual + i) % totalcasillas;
                        Casilla casilla = tablero.encontrar_casilla_posicion(nuevaPos);
                        if (casilla != null && "Transporte".equalsIgnoreCase(casilla.getTipo())) {
                            destino = (Transporte) casilla;
                        }
                    }
                    if (destino==null){
                        consola.imprimir("No se encontró una casilla de transporte.");
                        return;
                    }
                    avatar.setLugar(destino);
                    avatar.getLugar().evaluarCasilla(jugador,banca,0);

                    if(destino.getPosicion()< posActual) {
                        jugador.recibir(Valor.SUMA_VUELTA);
                        jugador.sumarVueltas();
                        consola.imprimir(jugador.getNombre() + " ha pasado por Salida y recibe " + (int)Valor.SUMA_VUELTA + "€.");
                    }
                    Jugador duenho= destino.getDuenho();
                    if(duenho != null && duenho != banca && duenho != jugador){
                        float alquiler = destino.getDuenho().contarTransportes();
                        alquiler = alquiler * 250000f * 2;
                        consola.imprimir("El jugador debe pagar el doble del alquiler: " + (int)alquiler + "€ a " + duenho.getNombre() + ".");
                        jugador.pagar(alquiler,duenho);
                        jugador.setPagoDeAlquileres(alquiler);
                    }

                    break;
            }
    }
}
