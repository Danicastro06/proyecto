package monopoly.cartas;

import monopoly.Valor;
import monopoly.casilla.Casilla;
import partida.*;

import java.util.ArrayList;

public abstract class Carta {

    abstract void accion( Jugador jugador, Jugador banca, int contador, ArrayList<Jugador> jugadores);

}
