package monopoly;

import monopoly.casilla.Casilla;
import monopoly.casilla.Especial;
import monopoly.casilla.Grupo;
import monopoly.casilla.*;
import monopoly.casilla.accion.CajaComunidad;
import monopoly.casilla.accion.Parking;
import monopoly.casilla.accion.Suerte;
import monopoly.casilla.propiedad.Propiedad;
import monopoly.casilla.propiedad.Servicio;
import monopoly.casilla.propiedad.Solar;
import monopoly.casilla.propiedad.Transporte;
import partida.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

public class Tablero {
    //Atributos.
    private ArrayList<ArrayList<Casilla>> posiciones; //Posiciones del tablero: se define como un arraylist de arraylists de casillas (uno por cada lado del tablero).
    private HashMap<String, Grupo> grupos; //Grupos del tablero, almacenados como un HashMap con clave String (será el color del grupo).
    private Jugador banca; //Un jugador que será la banca.


    //Constructor: únicamente le pasamos el jugador banca (que se creará desde el menú).
    public Tablero(Jugador banca) {
        this.banca = banca;
        this.posiciones = new ArrayList<>();
        // Creo los cuatro lados
        for (int i = 0; i < 4; i++) {               // posiciones.get(0) = Sur, (1) = Oeste, (2) = Norte, (3) = Este
            posiciones.add(new ArrayList<>());
        }
        this.grupos = new HashMap<>();
        generarCasillas();
    }


    //Método para crear todas las casillas del tablero. Formado a su vez por cuatro métodos (1/lado).
    private void generarCasillas() {
        Especial salida = new Especial("Salida", "Especial", 0, this);
        Especial carcel = new Especial("Carcel", "Especial", 10,  this);
        Parking parking = new Parking("Parking", "Especial", 20, this);
        Especial irCarcel = new Especial("IrCarcel", "Especial", 30, this);

        insertarLadoNorte(parking, irCarcel);
        insertarLadoSur(salida, carcel);
        insertarLadoOeste(carcel, parking);
        insertarLadoEste(irCarcel, salida);
    }

    //Método para insertar las casillas del lado norte.
    private void insertarLadoNorte(Casilla parking, Casilla irCarcel) {
        posiciones.get(2).add(parking);

        Solar solar12 = new Solar("Solar12", "Solar", 21, 2200000f, banca, this);
        solar12.setImpuesto(180000f);
        posiciones.get(2).add(solar12);
        posiciones.get(2).add(new Especial("Suerte", "Especial", 22, this));
        Solar solar13 = new Solar("Solar13", "Solar", 23, 2200000f, banca, this);
        solar13.setImpuesto(180000f);
        posiciones.get(2).add(solar13);
        Solar solar14 = new Solar("Solar14", "Solar", 24, 2400000f, banca, this);
        solar14.setImpuesto(200000f);
        posiciones.get(2).add(solar14);

        Grupo grupoRojo = new Grupo(solar12, solar13, solar14, "\u001B[31m");
        grupos.put("Rojo", grupoRojo);

        posiciones.get(2).add(new Transporte("Trans3", "Transporte", 25, 500000f, banca, this));
        Solar solar15 = new Solar("Solar15", "Solar", 26, 2600000f, banca, this);
        solar15.setImpuesto(220000f);
        posiciones.get(2).add(solar15);
        Solar solar16 = new Solar("Solar16", "Solar", 27, 2600000f, banca, this);
        solar16.setImpuesto(220000f);
        posiciones.get(2).add(solar16);
        posiciones.get(2).add(new Servicio("Serv2", "Servicio", 28, 500000f, banca, this));
        Solar solar17 = new Solar("Solar17", "Solar", 29, 2800000f, banca, this);
        solar17.setImpuesto(240000f);
        posiciones.get(2).add(solar17);

        Grupo grupoMarron = new Grupo(solar15, solar16, solar17, "\u001B[38;2;150;75;0m");
        grupos.put("Marron", grupoMarron);

        posiciones.get(2).add(irCarcel);
    }


    //Método para insertar las casillas del lado sur.
// Java
    private void insertarLadoSur(Casilla salida, Casilla carcel) {
        posiciones.get(0).add(salida);

        Solar solar1 = new Solar("Solar1", "Solar", 1, 600000f, banca, this);
        solar1.setImpuesto(20000f);
        posiciones.get(0).add(solar1);
        posiciones.get(0).add(new CajaComunidad("Caja", "Especial", 2,  this));
        Solar solar2 = new Solar("Solar2", "Solar", 3, 600000f, banca, this);
        solar2.setImpuesto(40000f);
        posiciones.get(0).add(solar2);
        posiciones.get(0).add(new Impuesto("Imp1", 4,"Impuesto", 2000000f, this));

        Grupo grupoNegrita = new Grupo(solar1, solar2, "\u001B[30m");
        grupos.put("Negrita", grupoNegrita);

        posiciones.get(0).add(new Transporte("Trans1", "Transporte", 5, 500000f, banca, this));

        Solar solar3 = new Solar("Solar3", "Solar", 6, 1000000f, banca, this);
        solar3.setImpuesto(60000f);
        posiciones.get(0).add(solar3);
        posiciones.get(0).add(new Suerte("Suerte", "Especial", 7, this));
        Solar solar4 = new Solar("Solar4", "Solar", 8, 1000000f, banca, this);
        solar4.setImpuesto(60000f);
        posiciones.get(0).add(solar4);
        Solar solar5 = new Solar("Solar5", "Solar", 9, 1200000f, banca, this);
        solar5.setImpuesto(80000f);
        posiciones.get(0).add(solar5);

        Grupo grupoCyan = new Grupo(solar3, solar4, solar5, "\u001B[36m");
        grupos.put("Cyan", grupoCyan);

        posiciones.get(0).add(carcel);
    }


    //Método que inserta casillas del lado oeste.
    // Java
    private void insertarLadoOeste(Casilla carcel, Casilla parking) {
        posiciones.get(1).add(carcel);

        Solar solar6 = new Solar("Solar6", "Solar", 11, 1400000f, banca, this);
        solar6.setImpuesto(100000f);
        posiciones.get(1).add(solar6);
        posiciones.get(1).add(new Servicio("Serv1", "Servicio", 12, 500000f, banca, this));
        Solar solar7 = new Solar("Solar7", "Solar", 13, 1400000f, banca, this);
        solar7.setImpuesto(100000f);
        posiciones.get(1).add(solar7);
        Solar solar8 = new Solar("Solar8", "Solar", 14, 1600000f, banca, this);
        solar8.setImpuesto(120000f);
        posiciones.get(1).add(solar8);

        Grupo grupoLila = new Grupo(solar6, solar7, solar8, "\u001B[35m");
        grupos.put("Lila", grupoLila);

        posiciones.get(1).add(new Transporte("Trans2", "Transporte", 15, 500000f, banca, this));
        Solar solar9 = new Solar("Solar9", "Solar", 16, 1800000f, banca, this);
        solar9.setImpuesto(140000f);
        posiciones.get(1).add(solar9);
        posiciones.get(1).add(new Especial("Caja", "Especial", 17, this));
        Solar solar10 = new Solar("Solar10", "Solar", 18, 1800000f, banca, this);
        solar10.setImpuesto(140000f);
        posiciones.get(1).add(solar10);
        Solar solar11 = new Solar("Solar11", "Solar", 19, 2200000f, banca, this);
        solar11.setImpuesto(160000f);
        posiciones.get(1).add(solar11);

        Grupo grupoCarne = new Grupo(solar9, solar10, solar11, "\u001B[33m");
        grupos.put("Carne", grupoCarne);

        posiciones.get(1).add(parking);
    }


    //Método que inserta las casillas del lado este.
// Java
    private void insertarLadoEste(Casilla irCarcel, Casilla salida) {
        posiciones.get(3).add(irCarcel);

        Solar solar18 = new Solar("Solar18", "Solar", 31, 3000000f, banca, this);
        solar18.setImpuesto(260000f);
        posiciones.get(3).add(solar18);
        Solar solar19 = new Solar("Solar19", "Solar", 32, 3000000f, banca, this);
        solar19.setImpuesto(260000f);
        posiciones.get(3).add(solar19);
        posiciones.get(3).add(new CajaComunidad("Caja", "Especial", 33,  this));
        Solar solar20 = new Solar("Solar20", "Solar", 34, 3200000f, banca, this);
        solar20.setImpuesto(280000f);
        posiciones.get(3).add(solar20);
        posiciones.get(3).add(new Transporte("Trans4", "Transporte", 35, 500000f, banca, this));


        Grupo grupoVerde = new Grupo(solar18, solar19, solar20, "\u001B[32m");
        grupos.put("Verde", grupoVerde);

        posiciones.get(3).add(new Suerte("Suerte", "Especial", 36,  this));
        Solar solar21 = new Solar("Solar21", "Solar", 37, 3500000f, banca, this);
        solar21.setImpuesto(350000f);
        posiciones.get(3).add(solar21);
        posiciones.get(3).add(new Impuesto("Imp2", 38, "Impuesto",2000000f, this));
        Solar solar22 = new Solar("Solar22", "Solar", 39, 4000000f, banca, this);
        solar22.setImpuesto(500000f);
        posiciones.get(3).add(solar22);

        Grupo grupoAzul = new Grupo(solar22, solar21, "\u001B[34m");
        grupos.put("Azul", grupoAzul);

        posiciones.get(3).add(salida);
    }


    //Para imprimir el tablero, modificamos el método toString().
    @Override
    public String toString() {
        //ancho fijo de cada celda
        int anchoCelda = 10;

        //tomamos los cuatro lados del tablero
        ArrayList<Casilla> norte = posiciones.get(2);
        ArrayList<Casilla> oeste  = posiciones.get(1);
        ArrayList<Casilla> este   = posiciones.get(3);
        ArrayList<Casilla> sur    = posiciones.get(0);

        StringBuilder sb = new StringBuilder();

        // línea superior de subrayado (solo espacios subrayados por cada casilla norte)
        sb.append(topUnderlineRow(norte, anchoCelda));

        // fila con las casillas del lado norte
        sb.append(topRow(norte, anchoCelda));

        // filas del centro con lados oeste y este y espacio en medio
        sb.append(middleRows(oeste, este, sur, anchoCelda));

        // fila inferior con las casillas del lado sur
        sb.append(bottomRow(oeste, sur, anchoCelda));

        return sb.toString();
    }


    // crea la fila de subrayado superior coloreada
    private String topUnderlineRow(java.util.List<Casilla> norte, int anchoCelda) {
        StringBuilder sb = new StringBuilder();
        for (Casilla c : norte) {
            if (c instanceof Solar){
                Solar s = (Solar) c;
                String color = (s.getGrupo() != null) ? s.getGrupo().getColor() : "";
                sb.append(' '); // espacio para alinear con la barra siguiente
                // pintamos (anchoCelda-1) espacios subrayados con el color
                sb.append(color).append("\u001B[4m").append(repeatSpace(anchoCelda - 1)).append("\u001B[0m");
            }
            else {
                String color = "";
                sb.append(' '); // espacio para alinear con la barra siguiente
                sb.append("\u001B[4m").append(repeatSpace(anchoCelda - 1)).append("\u001B[0m");
            }
        }
        sb.append("\n");
        return sb.toString();
    }

    // fila con las casillas del norte (cada celda con pipe |)
    private String topRow(java.util.List<Casilla> norte, int anchoCelda) {
        StringBuilder sb = new StringBuilder();
        for (Casilla c : norte) {
            sb.append("|").append(formatCell(c, anchoCelda));
        }
        sb.append("|\n");
        return sb.toString();
    }

    // filas centrales: izquierda (oeste) y derecha (este) y centro vacío o con subrayado del sur
    private String middleRows(java.util.List<Casilla> oeste, java.util.List<Casilla> este, java.util.List<Casilla> sur, int anchoCelda) {
        StringBuilder sb = new StringBuilder();
        int cols = posiciones.get(2).size();
        int middleRows = Math.max(0, cols - 2);
        int innerWidth = Math.max(0, middleRows * anchoCelda - 1);

        for (int r = 1; r <= middleRows; r++) {
            Casilla left = oeste.get(oeste.size() - 1 - r); // desde arriba hacia abajo
            Casilla right = este.get(r);

            sb.append("|").append(formatCell(left, anchoCelda)).append("|");

            if (r < middleRows) {
                // filas del centro normales: espacios
                sb.append(repeatSpace(innerWidth));
            } else {
                // última fila central: pintamos subrayado del lado sur (excluyendo esquinas)
                for (int j = 0; j < middleRows; j++) {
                    Casilla c = sur.get(sur.size() - 2 - j); // tomamos sur[segments] .. sur[1]
                    if(c instanceof Solar){
                        Solar s = (Solar) c;
                        String color = (s.getGrupo() != null) ? s.getGrupo().getColor() : "";
                        if (j == 0) {
                            // primer segmento sin espacio separador
                            sb.append(color).append("\u001B[4m").append(repeatSpace(anchoCelda - 1)).append("\u001B[0m");
                        } else {
                            // segmentos siguientes con 1 espacio separador
                            sb.append(' ').append(color).append("\u001B[4m").append(repeatSpace(anchoCelda - 1)).append("\u001B[0m");
                        }
                    }else{
                        if (j == 0) {
                            // primer segmento sin espacio separador
                            sb.append("\u001B[4m").append(repeatSpace(anchoCelda - 1)).append("\u001B[0m");
                        } else {
                            // segmentos siguientes con 1 espacio separador
                            sb.append(' ').append("\u001B[4m").append(repeatSpace(anchoCelda - 1)).append("\u001B[0m");
                        }
                    }
                }
            }

            sb.append("|").append(formatCell(right, anchoCelda)).append("|\n");
        }
        return sb.toString();
    }

    // fila inferior con las casillas del sur (izq->der)
    private String bottomRow(java.util.List<Casilla> oeste, java.util.List<Casilla> sur, int anchoCelda) {
        StringBuilder sb = new StringBuilder();
        // la esquina izquierda es oeste.get(0)
        sb.append("|").append(formatCell(oeste.get(0), anchoCelda));
        // añadimos las casillas del sur excepto la esquina derecha (último elemento)
        for (int i = sur.size() - 2; i >= 0; i--) {
            sb.append("|").append(formatCell(sur.get(i), anchoCelda));
        }
        sb.append("|\n");
        return sb.toString();
    }

    private String formatCell(Casilla c, int anchoCelda) {
        if( c instanceof Solar) {
            Solar s = (Solar) c;
            String color = s.getGrupo().getColor();

            int sitioCelda = anchoCelda - 1;

            java.util.List<partida.Avatar> avs = c.getAvatares();
            int totalAvs = (avs != null) ? avs.size() : 0;
            int espacioAvatares = (totalAvs > 0) ? Math.min(totalAvs, Math.max(1, (sitioCelda) / 2)) * 2 : 0;
            int espacioNombre = sitioCelda - espacioAvatares;

            String name = c.getNombre() == null ? "" : c.getNombre();
            if (name.length() > espacioNombre) {
                name = name.substring(0, Math.max(0, espacioNombre));
            }

            StringBuilder markers = new StringBuilder();
            for (int i = 0; i < Math.min(totalAvs, espacioAvatares / 2); i++) {
                String id = avs.get(i).getId();
                markers.append('&');
                if (id != null && !id.isEmpty()) markers.append(id);
            }

            String contenido = name + markers.toString();
            contenido = padRight(contenido, sitioCelda);

            return color + "\u001B[4m" + contenido + "\u001B[0m";
        }
        else{
            String color = "";

            int sitioCelda = anchoCelda - 1;

            java.util.List<partida.Avatar> avs = c.getAvatares();
            int totalAvs = (avs != null) ? avs.size() : 0;
            int espacioAvatares = (totalAvs > 0) ? Math.min(totalAvs, Math.max(1, (sitioCelda) / 2)) * 2 : 0;
            int espacioNombre = sitioCelda - espacioAvatares;

            String name = c.getNombre() == null ? "" : c.getNombre();
            if (name.length() > espacioNombre) {
                name = name.substring(0, Math.max(0, espacioNombre));
            }

            StringBuilder markers = new StringBuilder();
            for (int i = 0; i < Math.min(totalAvs, espacioAvatares / 2); i++) {
                String id = avs.get(i).getId();
                markers.append('&');
                if (id != null && !id.isEmpty()) markers.append(id);
            }

            String contenido = name + markers.toString();
            contenido = padRight(contenido, sitioCelda);

            return color + "\u001B[4m" + contenido + "\u001B[0m";
        }
    }


    // repite espacios n veces
    private String repeatSpace(int n) {
        if (n <= 0) return "";
        StringBuilder s = new StringBuilder(n);
        for (int i = 0; i < n; i++) s.append(' ');
        return s.toString();
    }

    // rellena a la derecha una cadena hasta longitud len
    private String padRight(String s, int len) {
        if (s == null) s = "";
        if (s.length() >= len) return s.substring(0, len);
        return s + repeatSpace(len - s.length());
    }


    //Método usado para buscar la casilla con el nombre pasado como argumento:
    public Casilla encontrar_casilla(String nombre) {
        for (ArrayList<Casilla> lado : posiciones) {
            for (Casilla casilla : lado) {
                if (casilla.getNombre().equals(nombre)) {
                    return casilla;
                }
            }
        }
        return null;
    }

    //Método usado para buscar la casilla con la posicion pasada como argumento:
    public Casilla encontrar_casilla_posicion(int posicion) {
        for (ArrayList<Casilla> lado : posiciones) {
            for (Casilla casilla : lado) {
                if (casilla.getPosicion() == posicion) {
                    return casilla;
                }
            }
        }
        return null;
    }

    public java.util.List<Casilla> getTodasCasillas() {
        ArrayList<Casilla> todas = new ArrayList<>();
        for (ArrayList<Casilla> lado : posiciones) {
            if (lado != null) todas.addAll(lado);
        }
        return java.util.Collections.unmodifiableList(todas);
    }

    public java.util.List<Casilla> getPropiedadesEnVenta() {
        ArrayList<Casilla> res = new ArrayList<>();
        for (ArrayList<Casilla> lado : posiciones) {
            if (lado == null) continue;
            for (Casilla c : lado) {
                if (c == null) continue;
                String tipo = c.getTipo() == null ? "" : c.getTipo().toLowerCase();
                if ((tipo.equals("solar") || tipo.equals("transporte") || tipo.equals("servicio"))){
                    Propiedad p = (Propiedad) c;
                    if(p.getDuenho() == null || p.getDuenho() == banca) {
                        res.add(c);
                    }
                }
            }
        }
        return java.util.Collections.unmodifiableList(res);
    }

    public ArrayList<Grupo> getGrupos() {
        return new ArrayList<>(grupos.values());
    }

}
