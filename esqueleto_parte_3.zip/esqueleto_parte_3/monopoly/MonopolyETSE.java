package monopoly;

import partida.Jugador;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import static monopoly.Juego.consola;

public class MonopolyETSE {
    private ArrayList<Jugador> jugadores = new ArrayList<>();
    private int turnoActual = 0;
    private Tablero tablero;
    private int parkingBote = 0;
    private Jugador banca;
    private Juego menu;

    public static void main(String[] args) {
        MonopolyETSE app = new MonopolyETSE();

        try {
            if (args != null && args.length > 0 && args[0] != null && !args[0].isEmpty()) {
                File f = new File(args[0]);
                if (f.exists() && f.isFile()) {
                    consola.imprimir("Iniciando ejecución desde fichero: " + args[0]);
                    app.ejecutarDesdeFichero(args[0]);
                } else {
                    consola.imprimir("Archivo no encontrado. Iniciando modo consola...");
                    app.ejecutarDesdeConsola();
                }
            } else {
                consola.imprimir("Iniciando modo consola...");
                app.ejecutarDesdeConsola();
            }
        } catch (Exception e) {
            System.err.println("Error iniciando la aplicación: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Constructor
    public MonopolyETSE() {
        banca = new Jugador(); // banca especial
        tablero = new Tablero(banca);
        menu = new Juego();
    }

    // Modo consola
    private void ejecutarDesdeConsola() {
        consola.imprimir("Bienvenido a Monopoly ETSE - Parte 1");

        // Mostrar opciones al inicio
        mostrarOpciones();

        while (true) {
            String linea = consola.leer("$> ");
            if ( linea.equalsIgnoreCase("salir")) {
                consola.imprimir("Saliendo del juego...");
                break;
            }
            menu.procesarComando(linea);

            // Mostrar opciones después de cada comando
            mostrarOpciones();
        }

    }



    // Desde fichero
    private void ejecutarDesdeFichero(String nombreFichero) {
        try (Scanner sc = new Scanner(new File(nombreFichero))) {
            while (sc.hasNextLine()) {
                String comando = sc.nextLine().trim();
                if (comando.isEmpty()) continue;
                consola.imprimir("$> " + comando);
                menu.procesarComando(comando);
            }
        } catch (FileNotFoundException e) {
            consola.imprimir("Error: no se encontró el fichero " + nombreFichero);
        }
        // Al acabr el fichero, pasar a modo consola
        ejecutarDesdeConsola();
    }


    // Mostrar opciones dinámicas según jugadores y propiedades
    private void mostrarOpciones() {
        consola.imprimir("\nOpciones disponibles:");
        consola.imprimir(" 1. crear jugador <nombre> <tipoAvatar>");
        consola.imprimir(" 2. ver tablero");
        consola.imprimir(" 3. lanzar dados <suma>");
        consola.imprimir(" 4. Jugador ( Turno actual ) ");
        consola.imprimir(" 5. listar jugadores");
        consola.imprimir(" 6. describir jugador <nombre>");
        consola.imprimir(" 7. lanzar dados");
        consola.imprimir(" 8. acabar turno");
        consola.imprimir(" 9. salir carcel");
        consola.imprimir(" 10. comprar <casilla>");
        consola.imprimir(" 11. listar enventa");
        consola.imprimir(" 12. describir <casilla>");
        consola.imprimir(" 13. edificar <tipo>");
        consola.imprimir(" 14. listar edificios");
        consola.imprimir(" 15. listar edificios <grupo>");
        consola.imprimir(" 16. hipotecar <casilla>");
        consola.imprimir(" 17. deshipotecar <casilla>");
        consola.imprimir(" 18. vender <tipo_edificio> <nombre_casilla> <numero>");
        consola.imprimir(" 19. estadisticas <nombre_jugador>");
        consola.imprimir(" 20. estadisticas");
        consola.imprimir(" 21. salir\n");
    }

    // Procesar cada comando (delegar a Menu)
    private void procesarComando(String linea) {
        menu.procesarComando(linea);
    }
}