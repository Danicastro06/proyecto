package monopoly.edificios;
import monopoly.casilla.Casilla;
import monopoly.casilla.propiedad.Solar;
import partida.*;

public abstract class Edificio {
    private String id;
    private Jugador propietario;
    private String tipo;
    private float coste;
    private Solar casilla;
    private float alquiler;
    private float hipoteca;
    // Contador estático para generar IDs únicos


    public Edificio() {
    }

    public Edificio(String id, String tipo, int coste, Jugador propietario, Solar casilla, float alquiler, float hipoteca) {
        this.id = id;
        this.tipo = tipo;
        this.coste = coste;
        this.propietario = propietario;
        this.casilla = casilla;
        this.alquiler = alquiler;
        this.hipoteca = hipoteca;
    }


    public String getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public float getCoste() {
        return coste;
    }

    public Jugador getPropietario() {
        return propietario;
    }

    public Solar getCasilla() {
        return casilla;
    }

    public float getAlquiler() {
        return alquiler;
    }

    public void setPropietario(Jugador propietario) {
        this.propietario = propietario;
    }

    public void setCasilla(Solar casilla) {
        this.casilla = casilla;
    }

    public void setAlquiler(float alquiler) {
        this.alquiler = alquiler;
    }

    public void setCoste(float coste) {
        this.coste = coste;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


}