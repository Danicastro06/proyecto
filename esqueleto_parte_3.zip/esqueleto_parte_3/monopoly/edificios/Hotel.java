package monopoly.edificios;

import monopoly.casilla.Casilla;
import monopoly.casilla.propiedad.Solar;
import partida.Jugador;
import static monopoly.Juego.consola;

public class Hotel extends Edificio {
    private static int contadorHoteles = 0;


    public Hotel(){

    }

    public Hotel(String id, String tipo, int coste, Jugador propietario, Solar casilla, float alquiler, float hipoteca) {
        super( id,  tipo,  coste,  propietario, casilla, alquiler, hipoteca);
    }

    public void construir_hotel(Jugador propietario, Solar casilla) {
        if (casilla.getNumHoteles() >= 1 || casilla.getNumCasas() < 4 ) {
            consola.imprimir("No se puede construir un hotel en la casilla " + casilla.getNombre());
            return;
        }
        String color = casilla.getGrupo().getColor();
        switch (color) {
            case "\u001B[30m":
                this.setCoste(500000f);
                setAlquilerHotel(casilla.getNombre());
                break;
            case "\u001B[36m":
                this.setCoste(500000f);
                setAlquilerHotel(casilla.getNombre());
                break;
            case "\u001B[35m":
                this.setCoste(1000000f);
                setAlquilerHotel(casilla.getNombre());
                break;
            case "\u001B[33m":
                this.setCoste(1000000f);
                setAlquilerHotel(casilla.getNombre());
                break;
            case "\u001B[31m":
                this.setCoste(1500000f);
                setAlquilerHotel(casilla.getNombre());
                break;
            case "\u001B[38;2;150;75;0m":
                this.setCoste(1000000f);
                setAlquilerHotel(casilla.getNombre());
                break;
            case "\u001B[32m":
                this.setCoste(2000000f);
                setAlquilerHotel(casilla.getNombre());
                break;
            case "\u001B[34m":
                this.setCoste(2000000f);
                setAlquilerHotel(casilla.getNombre());
                break;
            default:
                break;
        }

        if(propietario.pagarBanca(this.getCoste()) == 0) {
            propietario.setDineroInvertido(this.getCoste());
            contadorHoteles++;
            String id =  "hotel-" + contadorHoteles;
            this.setId(id);
            String tipo = "hotel";
            this.setTipo(tipo);
            this.setPropietario(propietario);
            this.setCasilla(casilla);
            casilla.setEdificio(this);
            //Eliminar las 4 casas de la casilla
            casilla.setNumCasas(0);
            consola.imprimir("El jugador " + propietario.getNombre() + " edifica un hotel en la casilla " + casilla.getNombre() + " por " + getCoste() + "€\n" + "Fortuna restante: " + (propietario.getFortuna()) + "€");
        }
        else{
            consola.imprimir("No tienes suficiente fortuna para construir un hotel en la casilla " + casilla.getNombre());
        }
    }
    public void setAlquilerHotel(String nombre) {
        if (nombre == null) return;
        String n = nombre.trim().toLowerCase();
        switch (n) {
            case "solar1":  setAlquiler(2500000f); break;
            case "solar2":  setAlquiler(4500000f); break;
            case "solar3":  setAlquiler(5500000f); break;
            case "solar4":  setAlquiler(5500000f); break;
            case "solar5":  setAlquiler(6000000f); break;
            case "solar6":  setAlquiler(7500000f); break;
            case "solar7":  setAlquiler(7500000f); break;
            case "solar8":  setAlquiler(9000000f); break;
            case "solar9":  setAlquiler(9500000f); break;
            case "solar10": setAlquiler(9500000f); break;
            case "solar11": setAlquiler(10000000f); break;
            case "solar12": setAlquiler(10500000f); break;
            case "solar13": setAlquiler(10500000f); break;
            case "solar14": setAlquiler(11000000f); break;
            case "solar15": setAlquiler(11500000f); break;
            case "solar16": setAlquiler(11500000f); break;
            case "solar17": setAlquiler(12000000f); break;
            case "solar18": setAlquiler(12750000f); break;
            case "solar19": setAlquiler(12750000f); break;
            case "solar20": setAlquiler(14000000f); break;
            case "solar21": setAlquiler(17000000f); break;
            case "solar22": setAlquiler(20000000f); break;
            default:
                consola.imprimir("Nombre no corresponde a Solar1..Solar22: " + nombre);
                break;
        }
    }
}
