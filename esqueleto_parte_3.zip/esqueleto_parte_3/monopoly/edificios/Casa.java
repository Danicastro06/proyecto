package monopoly.edificios;

import monopoly.casilla.Casilla;
import partida.Jugador;
import monopoly.casilla.propiedad.Solar;
import static monopoly.Juego.consola;

public class Casa extends Edificio {

    private static int contadorCasas = 0;


    public Casa(){

    }

    public Casa(String id, String tipo, int coste, Jugador propietario, Solar casilla, float alquiler, float hipoteca) {
        super( id,  tipo,  coste,  propietario, casilla, alquiler, hipoteca);
    }

    public void construir_casa(Jugador propietario, Solar casilla){
        if(casilla.getNumCasas() >= 4 || casilla.getNumHoteles() >=1){
            consola.imprimir("No se pueden construir más casas en la casilla " + casilla.getNombre());
            return;
        }
        String color = casilla.getGrupo().getColor();
        switch (color) {
            case "\u001B[34m":
                this.setCoste(2000000f);
                setAlquilerCasa(casilla.getNombre());
                break;
            case "\u001B[30m":
                this.setCoste(500000f);
                setAlquilerCasa(casilla.getNombre());
                break;
            case "\u001B[36m":
                this.setCoste(500000f);
                setAlquilerCasa(casilla.getNombre());
                break;
            case "\u001B[35m":
                this.setCoste(1000000f);
                setAlquilerCasa(casilla.getNombre());
                break;
            case "\u001B[33m":
                this.setCoste(1000000f);
                setAlquilerCasa(casilla.getNombre());
                break;
            case "\u001B[31m":
                this.setCoste(1500000f);
                setAlquilerCasa(casilla.getNombre());
                break;
            case "\u001B[38;2;150;75;0m":
                this.setCoste(1500000f);
                setAlquilerCasa(casilla.getNombre());
                break;
            case "\u001B[32m":
                this.setCoste(2000000f);
                setAlquilerCasa(casilla.getNombre());
                break;
            default:
                break;
        }
        if(propietario.pagarBanca(this.getCoste()) == 0) {
            consola.imprimir("El jugador " + propietario.getNombre() + " edifica una casa en la casilla " + casilla.getNombre() + " por " + getCoste() + "€\n" + "Fortuna restante: " + (propietario.getFortuna()) + "€");
            propietario.setDineroInvertido(this.getCoste());
            contadorCasas++;
            this.setTipo("casa");
            String id  = "casa-" + contadorCasas;
            this.setId(id);
            this.setPropietario(propietario);
            this.setCasilla(casilla);
            casilla.setEdificio(this);
        }
        else{
            consola.imprimir("No tienes suficiente fortuna para construir una casa en la casilla " + casilla.getNombre());
        }
    }

    public void setAlquilerCasa(String nombre) {
        if (nombre == null) return;
        String n = nombre.trim().toLowerCase();
        switch (n) {
            case "solar1":  setAlquiler(400000f); break;
            case "solar2":  setAlquiler(800000f); break;
            case "solar3":  setAlquiler(1000000f); break;
            case "solar4":  setAlquiler(1000000f); break;
            case "solar5":  setAlquiler(1250000f); break;
            case "solar6":  setAlquiler(1500000f); break;
            case "solar7":  setAlquiler(1500000f); break;
            case "solar8":  setAlquiler(1750000f); break;
            case "solar9":  setAlquiler(1850000f); break;
            case "solar10": setAlquiler(1850000f); break;
            case "solar11": setAlquiler(2000000f); break;
            case "solar12": setAlquiler(2200000f); break;
            case "solar13": setAlquiler(2200000f); break;
            case "solar14": setAlquiler(2325000f); break;
            case "solar15": setAlquiler(2450000f); break;
            case "solar16": setAlquiler(2450000f); break;
            case "solar17": setAlquiler(2600000f); break;
            case "solar18": setAlquiler(2750000f); break;
            case "solar19": setAlquiler(2750000f); break;
            case "solar20": setAlquiler(3000000f); break;
            case "solar21": setAlquiler(3250000f); break;
            case "solar22": setAlquiler(4250000f); break;
            default:
                consola.imprimir("Nombre no corresponde a Solar1..Solar22: " + nombre);
                break;
        }
    }
}
