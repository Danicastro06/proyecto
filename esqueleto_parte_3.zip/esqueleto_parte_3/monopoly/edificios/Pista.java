package monopoly.edificios;

import monopoly.casilla.Casilla;
import monopoly.casilla.propiedad.Solar;
import partida.Jugador;
import static monopoly.Juego.consola;

public class Pista extends Edificio {
    private static int contadorPistas = 0;

    public Pista(){

    }

    public Pista(String id, String tipo, int coste, Jugador propietario, Solar casilla, float alquiler, float hipoteca) {
        super( id,  tipo,  coste,  propietario, casilla, alquiler, hipoteca);
    }

    public void construir_pista(Jugador propietario, Solar casilla){
        if(casilla.getNumHoteles()!=1 || casilla.getNumPiscinas()!=1){
            consola.imprimir("No se pueden construir pistas en la casilla " + casilla.getNombre());
            return;
        }
        if(casilla.getNumPistas() ==1){
            consola.imprimir("No se pueden construir mas pistas en la casilla " + casilla.getNombre());
            return;
        }
        String color = casilla.getGrupo().getColor();
        switch (color) {
            case "\u001B[30m":
                this.setCoste(200000f);
                setAlquilerPistaPiscina(casilla.getNombre());
                break;
            case "\u001B[36m":
                this.setCoste(200000f);
                setAlquilerPistaPiscina(casilla.getNombre());
                break;
            case "\u001B[35m":
                this.setCoste(400000f);
                setAlquilerPistaPiscina(casilla.getNombre());
                break;
            case "\u001B[33m":
                this.setCoste(400000f);
                setAlquilerPistaPiscina(casilla.getNombre());
                break;
            case "\u001B[31m":
                this.setCoste(600000f);
                setAlquilerPistaPiscina(casilla.getNombre());
                break;
            case "\u001B[38;2;150;75;0m":
                this.setCoste(600000f);
                setAlquilerPistaPiscina(casilla.getNombre());
                break;
            case "\u001B[32m":
                this.setCoste(800000f);
                setAlquilerPistaPiscina(casilla.getNombre());
                break;
            case "\u001B[34m":
                this.setCoste(800000f);
                setAlquilerPistaPiscina(casilla.getNombre());
                break;
            default:
                break;
        }
        if(propietario.pagarBanca(this.getCoste()) == 0) {
            contadorPistas++;
            String id = "pista-" + contadorPistas;
            this.setId(id);
            String tipo = "pista-" + contadorPistas;
            this.setId(tipo);
            this.setPropietario(propietario);
            this.setCasilla(casilla);
            casilla.setEdificio(this);
            propietario.setDineroInvertido(this.getCoste());
            consola.imprimir("El jugador " + propietario.getNombre() + " edifica una pista en la casilla " + casilla.getNombre() + " por " + getCoste() + "€\n" + "Fortuna restante: " + (propietario.getFortuna()) + "€");
        }else{
            consola.imprimir("No tienes suficiente fortuna para construir una pista en la casilla " + casilla.getNombre());
        }
    }

    public void setAlquilerPistaPiscina(String nombre) {
        if (nombre == null) return;
        String n = nombre.trim().toLowerCase();
        switch (n) {
            case "solar1":  setAlquiler(500000f); break;
            case "solar2":  setAlquiler(900000f); break;
            case "solar3":  setAlquiler(1100000f); break;
            case "solar4":  setAlquiler(1100000f); break;
            case "solar5":  setAlquiler(1200000f); break;
            case "solar6":  setAlquiler(1500000f); break;
            case "solar7":  setAlquiler(1500000f); break;
            case "solar8":  setAlquiler(1800000f); break;
            case "solar9":  setAlquiler(1900000f); break;
            case "solar10": setAlquiler(1900000f); break;
            case "solar11": setAlquiler(2000000f); break;
            case "solar12": setAlquiler(2100000f); break;
            case "solar13": setAlquiler(2100000f); break;
            case "solar14": setAlquiler(2200000f); break;
            case "solar15": setAlquiler(2300000f); break;
            case "solar16": setAlquiler(2300000f); break;
            case "solar17": setAlquiler(2400000f); break;
            case "solar18": setAlquiler(2550000f); break;
            case "solar19": setAlquiler(2550000f); break;
            case "solar20": setAlquiler(2800000f); break;
            case "solar21": setAlquiler(3400000f); break;
            case "solar22": setAlquiler(4000000f); break;
            default:
                consola.imprimir("Nombre no corresponde a Solar1..Solar22: " + nombre);
                break;
        }
    }


}
