package monopoly;

public interface Comando {
    void comprarPropiedad(String nombreCasilla);
    void hipotecar(String nombreCasilla);
    void deshipotecar(String nombreCasilla);
    void construirEdificio(String tipoEdificio);
    void venderEdificios(String nombreCasilla, String tipoEdificio, int cantidad);
    void listarJugadores();
    void listarVenta();
    void listarEdificios();
    void listarEdificiosGrupo(String colorGrupo);
    void describirJugador(String nombreJugador);
    void descCasilla(String nombreCasilla);
    void lanzarDados(Integer d1, Integer d2);
    void acabarTurno();
    void salirCarcel();
    void crearJugador(String nombre, String tipoAvatar);
    void estadisticasJuego();
    void mostrarEstadisticasJugador(String nombreJugador);
    void mostrarTurno();
}
