package monopoly.excepciones.N2;

public class ExcepcionPropiedad extends Exception { // Hereda de tu clase de Nivel 1
    public ExcepcionPropiedad(String mensaje) {
        super(mensaje);
    }
}