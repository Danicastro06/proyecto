package monopoly.excepciones.N2;

public class ExcepcionPropiedad {
}
