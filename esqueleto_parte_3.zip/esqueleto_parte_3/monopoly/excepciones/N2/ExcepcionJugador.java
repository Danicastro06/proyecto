package monopoly.excepciones.N2;

public class ExcepcionJugador extends Exception { // Hereda de tu clase de Nivel 1
    public ExcepcionJugador(String mensaje) {
        super(mensaje);
    }
}