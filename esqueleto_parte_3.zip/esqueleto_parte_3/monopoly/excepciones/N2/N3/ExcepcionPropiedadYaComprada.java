package monopoly.excepciones.N2.N3;

public class ExcepcionPropiedadYaComprada {
}
