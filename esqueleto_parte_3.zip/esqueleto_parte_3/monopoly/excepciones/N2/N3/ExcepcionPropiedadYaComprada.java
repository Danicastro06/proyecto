package monopoly.excepciones.N2.N3;

import monopoly.excepciones.N2.ExcepcionPropiedad;

public class ExcepcionPropiedadYaComprada extends ExcepcionPropiedad { // Hereda de Nivel 2
    public ExcepcionPropiedadYaComprada(String mensaje) {
        super(mensaje);
    }
}
