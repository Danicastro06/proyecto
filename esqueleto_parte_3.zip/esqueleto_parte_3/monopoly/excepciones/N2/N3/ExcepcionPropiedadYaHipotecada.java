package monopoly.excepciones.N2.N3;

import monopoly.excepciones.N2.ExcepcionPropiedad;

public class ExcepcionPropiedadYaHipotecada extends ExcepcionPropiedad {
    public ExcepcionPropiedadYaHipotecada(String message) {

        super(message);
    }
}
