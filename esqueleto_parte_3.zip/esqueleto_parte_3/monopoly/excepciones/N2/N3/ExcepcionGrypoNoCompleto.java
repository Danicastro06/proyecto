package monopoly.excepciones.N2.N3;

import monopoly.excepciones.N2.ExcepcionPropiedad;

public class ExcepcionGrypoNoCompleto extends ExcepcionPropiedad {
    public ExcepcionGrypoNoCompleto(String message) {
        super(message);
    }
}
