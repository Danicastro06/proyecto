package monopoly.excepciones.N2.N3;

import monopoly.excepciones.N2.ExcepcionJugador;

public class ExcepcionNoFondosSuficientes extends ExcepcionJugador {
    public ExcepcionNoFondosSuficientes(String message) {
        super(message);
    }
}
