package monopoly.excepciones.N2.N3;

import monopoly.excepciones.N2.ExcepcionJugador;

public class ExcepcionAccionInvalida extends ExcepcionJugador {
    public ExcepcionAccionInvalida(String message) {
        super(message);
    }
}
