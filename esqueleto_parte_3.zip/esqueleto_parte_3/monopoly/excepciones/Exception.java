package monopoly.excepciones;

public class Exception extends RuntimeException {
    public Exception(String message) {

        super(message);
    }
}
