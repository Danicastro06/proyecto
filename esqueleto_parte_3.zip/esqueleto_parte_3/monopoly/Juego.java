package monopoly;

import java.util.ArrayList;
import java.util.Scanner;

import monopoly.cartas.CajaComunidad;
import monopoly.cartas.Suerte;
import monopoly.casilla.Casilla;
import monopoly.casilla.Grupo;
import monopoly.casilla.Impuesto;
import monopoly.casilla.accion.Parking;
import monopoly.casilla.propiedad.Propiedad;
import monopoly.casilla.propiedad.Servicio;
import monopoly.casilla.propiedad.Solar;
import monopoly.casilla.propiedad.Transporte;
import monopoly.edificios.Casa;
import monopoly.edificios.Hotel;
import monopoly.edificios.Pista;
import monopoly.edificios.Piscina;
import monopoly.edificios.Edificio;
import monopoly.ConsolaNormal;
import partida.*;

public class Juego implements Comando {

    private ArrayList<Jugador> jugadores;
    private ArrayList<Avatar> avatares;
    private int turno = 0;
    private int lanzamientos;
    private Tablero tablero;
    private Dado dado1;
    private Dado dado2;
    private Jugador banca;
    private boolean tirado;
    private boolean solvente;
    private int contadorSuerte=0;
    private static final int MAX_SUERTE=7;
    private int contadorComunidad=0;
    private static final int MAX_CAJA=6;
    public static ConsolaNormal consola = new ConsolaNormal();

    public Juego() {
        // Crear banca primero
        this.banca = new Jugador(); // Jugador especial "banca"
        // Crear el tablero con la banca
        this.tablero = new Tablero(banca);
        // Iniciar la partida
        iniciarPartida();
    }

    //Método que inicializa el estado del juego
    private void iniciarPartida() {
        jugadores = new ArrayList<>();
        avatares = new ArrayList<>();
        dado1 = new Dado();
        dado2 = new Dado();

        // Tablero ya está inicializado correctamente con la banca
        Casilla casillaInicio = tablero.encontrar_casilla("Salida");
        banca.setLugar(casillaInicio);
        banca.setFortuna(Float.MAX_VALUE);

        turno = 0;
        lanzamientos = 0;
        tirado = false;
        solvente = true;

    }


    public void procesarComando(String linea) {
        analizarComando(linea);
    }


    /*Método que interpreta el comando introducido y toma la accion correspondiente.
     * Parámetro: cadena de caracteres (el comando).
     */
    private void analizarComando(String linea) {
        String[] partes = linea.split(" ");
        if (partes.length == 0) return;

        switch (partes[0].toLowerCase()) {
            case "crear":
                if (partes.length >= 4 && partes[1].equalsIgnoreCase("jugador")) {
                    crearJugador(partes[2], partes[3]);
                } else {
                    consola.imprimir("Uso: crear jugador <nombre> <tipoAvatar>");
                }
                break;

            case "listar":
                if (jugadores.isEmpty()) {
                    consola.imprimir("No hay jugadores creados todavía.");
                    return;
                }
                if (partes.length == 2 && partes[1].equalsIgnoreCase("jugadores")) {
                    listarJugadores();
                } else if (partes.length == 2 && partes[1].equalsIgnoreCase("enventa")) {
                    if (tablero.getPropiedadesEnVenta().isEmpty()) {
                        consola.imprimir("No hay propiedades en venta.");
                    } else {
                        listarVenta();
                    }
                } else if(partes.length == 2 && partes[1].equalsIgnoreCase("edificios")){
                    listarEdificios();
                }else if(partes.length == 3 && partes[1].equalsIgnoreCase("edificios")){
                    if(partes[2].equals("azul") || partes[2].equals("rojo") || partes[2].equals("verde") || partes[2].equals("amarillo") ||
                            partes[2].equals("morado") || partes[2].equals("cyan") || partes[2].equals("marron") || partes[2].equals("negrita")){
                        listarEdificiosGrupo(partes[2]);
                    }

                }else {
                    consola.imprimir("Uso: listar jugadores | listar enventa | listar edificios");
                }
                break;

            case "jugador":
                if (jugadores.isEmpty()) {
                    consola.imprimir("No hay jugadores creados todavía.");
                    return;
                }
                mostrarTurno();
                break;
            case "lanzar":
                if (jugadores == null || jugadores.size() < 2) {
                    consola.imprimir("Se necesitan al menos dos jugadores para lanzar dados.");
                    return;
                }
                Integer forcedD1 = null, forcedD2 = null;
                String expr = null;

                if (partes.length == 3 && partes[0].equalsIgnoreCase("lanzar") && partes[1].equalsIgnoreCase("dados")) {
                    expr = partes[2];
                } else if (partes.length == 2 && partes[0].equalsIgnoreCase("lanzar") && partes[1].equalsIgnoreCase("dados")) {
                    expr = null; // Tirada normal
                } else {
                    consola.imprimir("Uso: lanzar dados | lanzar dados <d1>+<d2>");
                    return;
                }

                if (expr != null && !expr.isEmpty()) {
                    try {
                        if (expr.contains("+")) {
                            String[] ops = expr.split("\\+");
                            if (ops.length != 2) throw new NumberFormatException();
                            int d1 = Integer.parseInt(ops[0]);
                            int d2 = Integer.parseInt(ops[1]);
                            if (d1 < 1 || d1 > 6 || d2 < 1 || d2 > 6) {
                                consola.imprimir("Cada dado debe estar entre 1 y 6.");
                                return;
                            }
                            forcedD1 = d1;
                            forcedD2 = d2; //
                        }
                    } catch (NumberFormatException ex) {
                        consola.imprimir("Formato inválido. Uso: lanzar [dados] | lanzar [dados] <d1>+<d2>");
                        return;
                    }
                }

                if (forcedD1 != null && forcedD2 != null) {
                    lanzarDados(forcedD1, forcedD2); // Exacto: d1 y d2
                } else {
                    lanzarDados(forcedD1, forcedD2); // Suma o tirada normal
                }
                break;
            case "acabar":
                if (jugadores.size() < 2) {
                    consola.imprimir("Se necesitan al menos dos jugadores para acabar turno.");
                    return;
                }
                if (partes.length == 2 && partes[1].equalsIgnoreCase("turno")) {
                    acabarTurno();
                } else {
                    consola.imprimir("Uso: acabar turno");
                }
                break;

            case "salir":
                if (jugadores.size() < 2) {
                    consola.imprimir("Se necesitan al menos dos jugadores para salir de la cárcel.");
                    return;
                }
                if (partes.length == 2 && partes[1].equalsIgnoreCase("carcel")) {
                    salirCarcel();
                }
                break;

            case "comprar":
                if (jugadores.size() < 2) {
                    consola.imprimir("Se necesitan al menos dos jugadores para comprar propiedades.");
                    return;
                }
                comprarPropiedad(partes[1]);
                break;

            case "describir":
                if (jugadores.isEmpty()) {
                    consola.imprimir("No hay jugadores creados todavía.");
                    return;
                }
                if (partes.length == 1) {
                    descCasilla(null);
                    break;
                }
                if (partes.length == 3 && partes[1].equalsIgnoreCase("jugador")) {
                    describirJugador(partes[2]);
                }
                else if(partes.length == 2) {
                    descCasilla(partes[1]);
                }
                else{
                    consola.imprimir("Uso: describir jugador <nombre> Ó describir casilla <nombre_casilla>");
                }
                break;

            case "ver":
                if (partes.length == 2 && partes[1].equalsIgnoreCase("tablero")) {
                    consola.imprimir(tablero.toString());
                } else {
                    consola.imprimir("Uso: ver tablero");
                }
                break;

            case "edificar":
                if (jugadores.isEmpty()) {
                    consola.imprimir("No hay jugadores creados todavía.");
                    return;
                }
                if (partes.length == 3 && partes[1].equalsIgnoreCase("casa")) {
                    try {
                        Integer.parseInt(partes[2]);
                    } catch (NumberFormatException e) {
                        consola.imprimir("Número de casas inválido: " + partes[2]);
                        return;
                    }
                    int numeroVeces = Integer.parseInt(partes[2]);
                    for (int i = 0; i < numeroVeces; i++) {
                        construirEdificio(partes[1]);
                    }
                }
                else if(partes.length == 2 && partes[1].equalsIgnoreCase("casa")) {
                    construirEdificio(partes[1]);
                } else if (partes.length == 2 && partes[1].equalsIgnoreCase("hotel")) {
                    construirEdificio(partes[1]);
                } else if (partes.length == 2 && partes[1].equalsIgnoreCase("piscina")) {
                    construirEdificio(partes[1]);
                } else if (partes.length == 2 && partes[1].equalsIgnoreCase("pista")) {
                    construirEdificio(partes[1]);
                } else {
                    consola.imprimir("Uso: Edificar casa | Edificar hotel | Edificar piscina | Edificar pista ");
                }
                break;
            case "hipotecar":
                if (jugadores.isEmpty()) {
                    consola.imprimir("No hay jugadores creados todavía.");
                    return;
                }
                if (partes.length == 2) {
                    hipotecar(partes[1]);
                } else{
                    consola.imprimir("Uso: hipotecar <nombre_casilla>");
                }
                break;
            case "deshipotecar":
                if (jugadores.isEmpty()) {
                    consola.imprimir("No hay jugadores creados todavía.");
                    return;
                }
                if (partes.length == 2) {
                    deshipotecar(partes[1]);
                } else {
                    consola.imprimir("Uso: deshipotecar <nombre_casilla>");
                }
                break;
            case "vender":
                if (jugadores.isEmpty()) {
                    consola.imprimir("No hay jugadores creados todavía.");
                    return;
                }
                if (partes.length == 4) {
                    int numero = 0;
                    try {
                        numero = Integer.parseInt(partes[3]);
                    } catch (NumberFormatException e) {
                        consola.imprimir("Número invalido: " + partes[3]);
                        return;
                    }
                    venderEdificios(partes[1], partes[2], numero);
                } else {
                    consola.imprimir("Uso: vender <tipo_edificio> <nombre_casilla> <numero>");
                }
                break;
            case "estadisticas":
                if (partes.length == 1) {
                    estadisticasJuego();
                } else if (partes.length == 2) {
                    mostrarEstadisticasJugador(partes[1]);
                } else {
                    consola.imprimir("Uso: estadisticas <nombreJugador>");
                }
                break;

            default:
                consola.imprimir("Comando no reconocido: " + linea);
                break;
        }
    }


    /*Método que realiza las acciones asociadas al comando 'describir jugador'.
     * Parámetro: comando introducido
     */
    private void describirJugadorImpl(String nombreJugador) {
        for (Jugador j : jugadores) {
            if (j.getNombre().equalsIgnoreCase(nombreJugador)) {
                consola.imprimir("{");
                consola.imprimir(" nombre: " + j.getNombre() + ",");
                consola.imprimir(" avatar: " + (j.getAvatar() != null ? j.getAvatar().getId() : "sin avatar") + ",");
                consola.imprimir(" fortuna: " + j.getFortuna() + ",");
                // Buscar propiedades en el tablero en lugar de usar j.getPropiedades() (por si no está implementado correctamente)
                ArrayList<String> nombres = new ArrayList<>();
                ArrayList<String> hipos = new ArrayList<>();
                ArrayList<String> edificios = new ArrayList<>();
                try {
                    for (Casilla c : tablero.getTodasCasillas()) {
                        if(c instanceof Propiedad){
                            Propiedad p = (Propiedad) c;
                            if (p != null && p.getDuenho() == j) {
                                nombres.add(c.getNombre());
                                if (p instanceof Solar) {
                                    Solar s = (Solar) p;
                                    ArrayList<Edificio> edificiosC = s.getEdificios();
                                    for (Edificio ed : edificiosC) {
                                        edificios.add(ed.getId());
                                    }
                                }
                                //if (c.estaHipotecada()) hipos.add(c.getNombre());
                            }
                        }

                    }
                } catch (Exception ignore) {}
                consola.imprimir(" propiedades: " + (nombres.isEmpty() ? "[]" : "[" + String.join(", ", nombres) + "]"));
                consola.imprimir(" Edificios: " + (edificios.isEmpty() ? "[]" : "[" + String.join(", ", edificios) + "]"));
                consola.imprimir(" hipotecas: " + (hipos.isEmpty() ? "[]" : "[" + String.join(", ", hipos) + "]"));
                consola.imprimir("}");
                return;
            }
        }
        consola.imprimir("Jugador " + nombreJugador + " no encontrado.");
    }

    @Override
    public void describirJugador(String nombreJugador){
        describirJugadorImpl(nombreJugador);
    }


    /*Método que realiza las acciones asociadas al comando 'describir avatar'.//No hay que hacerlo
     * Parámetro: id del avatar a describir.
     */
    private void descAvatar(String ID) {
    }

    /* Método que realiza las acciones asociadas al comando 'describir nombre_casilla'.
     * Parámetros: nombre de la casilla a describir.
     */
    private void descCasillaImpl(String nombre) {
        final String ANSI_RESET = "\u001B[0m";
        Casilla casilla = tablero.encontrar_casilla(nombre);
        if (casilla == null) {
            consola.imprimir("No existe la casilla: " + nombre);
            return;
        }
        String tipo = casilla.getTipo() == null ? "" : casilla.getTipo().toLowerCase();
        consola.imprimir("{");
        switch (tipo) {
            case "solar":
                Solar s= (Solar) casilla;
                String grupoStr = "sin grupo";
                Grupo g = s.getGrupo();
                if (g != null && g.getColor() != null) {
                    grupoStr=getNombreColorGrupo(g.getColor());
                }
                String propietario = "sin dueño";
                if (s.getDuenho() != banca) {
                    propietario = s.getDuenho().getNombre();
                }
                float alquiler = s.calcularAlquiler();
                float costeCasas = 0.0f;
                float alquilerCasas = 0.0f;
                float costeHotel = 0.0f;
                float alquilerHotel = 0.0f;
                float costePiscina = 0.0f;
                float alquilerPiscina = 0.0f;
                float costePista = 0.0f;
                float alquilerPista = 0.0f;
                for (Edificio e : s.getEdificios()) {
                    if (e.getTipo().equals("casa")) {
                        costeCasas += e.getCoste();
                        alquilerCasas += e.getAlquiler();
                    }
                    if (e.getTipo().equals("hotel")) {
                        costeHotel += e.getCoste();
                        alquilerHotel += e.getAlquiler();
                    }
                    if (e.getTipo().equals("piscina")) {
                        costePiscina += e.getCoste();
                        alquilerPiscina += e.getAlquiler();
                    }
                    if (e.getTipo().equals("pista")) {
                        costePista += e.getCoste();
                        alquilerPista += e.getAlquiler();
                    }
                }

                consola.imprimir("tipo: solar,");
                consola.imprimir("grupo: " + grupoStr + ",");
                consola.imprimir("propietario: " + propietario + ",");
                consola.imprimir("valor: " + (int)s.getValor() + ",");
                consola.imprimir("alquiler solar: " + (int)s.getImpuesto() + ",");
                consola.imprimir("valor hotel: "+ (int)costeHotel +",");
                consola.imprimir("valor casa: "+ (int)costeCasas + ",");
                consola.imprimir("valor piscina: "+ (int)costePiscina +",");
                consola.imprimir("valor pista de deporte: "+ (int)costePista +",");
                consola.imprimir("alquiler casa: " + (int)alquilerCasas + ",");
                consola.imprimir("alquiler hotel: " + (int)alquilerHotel + ",");
                consola.imprimir("alquiler piscina: " + (int)alquilerPiscina + ",");
                consola.imprimir("alquiler pista de deporte: " + (int)alquilerPista + ",");
                consola.imprimir("alquiler total: " + (int)alquiler + ",");

                break;
            case "servicio":
            case "servicios":
                Servicio serv= (Servicio) casilla;
                String propietarioServicio = "sin dueño";
                try {
                    if (serv.getDuenho() != banca) {
                        propietarioServicio = serv.getDuenho().getNombre();
                    }
                } catch (Throwable ignored) {}
                consola.imprimir("tipo: servicio,");
                consola.imprimir("propietario: " + propietarioServicio + ",");
                consola.imprimir("valor: " + (int)serv.getValor() + ",");
                break;
            case "transporte":
                Transporte t= (Transporte) casilla;
                String propietarioTransporte = "sin dueño";
                try {
                    if (t.getDuenho() != banca) {
                        propietarioTransporte = t.getDuenho().getNombre();
                    }
                } catch (Throwable ignored) {}
                consola.imprimir("tipo: transporte,");
                consola.imprimir("propietario: " + propietarioTransporte + ",");
                consola.imprimir("valor: " + (int)t.getValor() + ",");
                break;
            case "impuesto":
                Impuesto i= (Impuesto) casilla;
                consola.imprimir("tipo: impuesto,");
                consola.imprimir("a pagar: " + i.getImpuesto());
                break;
            case "especial":
                if(casilla.getNombre().equalsIgnoreCase("parking")) {
                    Parking park= (Parking) casilla;
                    consola.imprimir("bote: " + park.getValor() + ",");
                    ArrayList<Avatar> avs = casilla.getAvatares();
                    ArrayList<String> jugadores = new ArrayList<>();
                    for (Avatar av : avs) {
                        if (av.getJugador() != null) {
                            jugadores.add( av.getJugador().getNombre() );
                        }
                    }
                    consola.imprimir("jugadores: " + jugadores );
                }
                else if(casilla.getNombre().equalsIgnoreCase("carcel")){
                    consola.imprimir("salir: 500000,");
                    ArrayList<Avatar> avataresCarcel = casilla.getAvatares();
                    ArrayList<String> jugadoresCarcel = new ArrayList<>();
                    for (Avatar av : avataresCarcel) {
                        if (av.getJugador() != null) {
                            int tiradas = av.getJugador().getTiradasCarcel();
                            jugadoresCarcel.add("[" + av.getJugador().getNombre() + "," + tiradas + "]");
                        }
                    }
                    consola.imprimir("jugadores: " + jugadoresCarcel);
                }
                break;
            default:
                consola.imprimir("tipo: " + tipo);
                break;
        }
        consola.imprimir("}");
        System.out.print(ANSI_RESET);
    }
    @Override
    public void descCasilla(String nombre){
        descCasillaImpl(nombre);
    }

    //Método que ejecuta todas las acciones relacionadas con el comando 'lanzar dados'.

    private void lanzarDadosImpl(Integer forcedD1, Integer forcedD2) {
        if (jugadores == null || jugadores.isEmpty()) return;
        Jugador jugador = jugadores.get(turno);
        if (jugador == null || jugador.isEnCarcel()) {
            if (jugador != null && jugador.isEnCarcel()) {
                consola.imprimir("Estás en la cárcel, no puedes lanzar los dados.");
            }
            return;
        }
        dado1 = new Dado();
        dado2 = new Dado();
        int d1Val, d2Val, total;

        if(forcedD1 == null || forcedD2 == null){
            d1Val = dado1.hacerTirada();
            d2Val = dado2.hacerTirada();
            total = d1Val + d2Val;
        }else{
            if (forcedD1 < 1 || forcedD1 > 6 || forcedD2 < 1 || forcedD2 > 6) {
                consola.imprimir("Cada dado debe estar entre 1 y 6.");
                return;
            }
            d1Val = dado1.forzarTirada(forcedD1);
            d2Val = dado2.forzarTirada(forcedD2);
            total = d1Val + d2Val;
        }

        Avatar avatar = jugador.getAvatar();
        if (avatar == null) {
            consola.imprimir("El jugador " + jugador.getNombre() + " no tiene avatar asignado. No se puede mover.");
            return;
        }

        if(d1Val == d2Val){
            jugador.sumarTiradasCarcel();
            if(jugador.getTiradasCarcel() == 3){
                consola.imprimir("El jugador " + jugador.getNombre() + " ha sacado dobles 3 veces y va a la cárcel.");
                Casilla ircarcel = tablero.encontrar_casilla("IrCarcel");
                avatar.setLugar(ircarcel);
                avatar.getLugar().evaluarCasilla(jugador,banca,0);
                jugador.resetTiradasCarcel();
                return;
            }
        }else{
            jugador.resetTiradasCarcel();
        }
        ArrayList<ArrayList<Casilla>> casillasPorLados = new ArrayList<>();
        try {
            java.util.List<Casilla> todas = tablero.getTodasCasillas();
            casillasPorLados.add(todas != null ? new ArrayList<>(todas) : new ArrayList<>());
        } catch (Throwable ignored) {
            casillasPorLados.add(new ArrayList<>());
        }

        try {
            avatar.moverAvatar(casillasPorLados, total);
        } catch (Throwable t) {
            consola.imprimir("Error al mover el avatar: " + t.getMessage());
            return;
        }

        Casilla siguiente = avatar.getLugar();
        if (siguiente == null) {
            consola.imprimir("Error: no se ha podido determinar la casilla destino.");
            return;
        }

        consola.imprimir("El avatar " + (avatar != null ? avatar.getId() : "sin avatar")
                + " lanza " + d1Val + "+" + d2Val + " (" + total + ") y se mueve a " + siguiente.getNombre());

        try {
            siguiente.evaluarCasilla(jugador, banca, total);
        } catch (Throwable t) {
            consola.imprimir("Error al evaluar la casilla: " + t.getMessage());
        }
        if ("especial".equalsIgnoreCase(siguiente.getTipo()) && siguiente.getNombre().equalsIgnoreCase("suerte")) {
            Suerte suerte = new Suerte();
            contadorSuerte=(contadorSuerte % MAX_SUERTE)+1;
            suerte.accion(jugador, banca, contadorSuerte,jugadores);
        } else if ("especial".equalsIgnoreCase(siguiente.getTipo()) && siguiente.getNombre().equalsIgnoreCase("caja")) {
            CajaComunidad caja = new CajaComunidad();
            contadorComunidad = (contadorComunidad % MAX_CAJA) + 1;
            caja.accion(jugador, banca, contadorComunidad, jugadores);
        }

        consola.imprimir(tablero.toString());
    }

    @Override
    public void lanzarDados(Integer forcedD1, Integer forcedD2){
        lanzarDadosImpl(forcedD1, forcedD2);
    }



    /*Método que ejecuta todas las acciones realizadas con el comando 'comprar nombre_casilla'.
     * Parámetro: cadena de caracteres con el nombre de la casilla.
     */
    private void comprarPropiedadImpl(String nombreCasilla) {
        if (jugadores.isEmpty()) return;
        Jugador jugador = jugadores.get(turno);
        Avatar avatar = jugador.getAvatar();
        Casilla lugar = avatar.getLugar();
        if (lugar != null && lugar.getNombre().equals(nombreCasilla)){
            Casilla c = tablero.encontrar_casilla(nombreCasilla);
            if (c == null) {
                consola.imprimir("No existe la casilla: " + nombreCasilla);
                return;
            }
            String tipo = c.getTipo();
            if (!tipo.equals("Solar") && !tipo.equals("Transporte") && !tipo.equals("Servicio")) {
                consola.imprimir("Esta casilla no se puede comprar (tipo: " + tipo + ").");
                return;
            }
            Propiedad p = (Propiedad) c;
            if (p.getDuenho() != null && p.getDuenho() != banca) {
                consola.imprimir("Esta casilla ya tiene dueño.");
                return;
            }
            if (jugador.getFortuna() < p.getValor()) {
                consola.imprimir("No tienes suficiente fortuna para comprar esta casilla (necesitas " + (int)p.getValor() + "€, tienes " + (int)jugador.getFortuna() + "€).");
                return;
            }
            int resultado = p.comprarCasilla(jugador, banca);
            if (resultado == 0) {
                consola.imprimir("El jugador " + jugador.getNombre() + " compra " + c.getNombre() + " por " + (int)p.getValor() + "€. Fortuna restante: " + (int)jugador.getFortuna() + "€.");
            } else {
                consola.imprimir("No se pudo comprar la propiedad " + c.getNombre() + ".");
            }
        }else {
            consola.imprimir("No puedes comprar la casilla " + nombreCasilla + " porque no estás en ella.");
        }
    }
    @Override
    public void comprarPropiedad(String nombreCasilla){
        comprarPropiedadImpl(nombreCasilla);
    }

    ///  Metodo que añade edificios a cada jugador
    private void construirEdificioImpl(String tipoEdificio) {
        String tipoE = tipoEdificio.trim().toLowerCase();
        if (jugadores.isEmpty()) return;
        Jugador jugador = jugadores.get(turno);
        Avatar avatar = jugador.getAvatar();
        Casilla c = avatar.getLugar();
        String tipo = c.getTipo();
        if (!tipo.equals("Solar")) {
            consola.imprimir("Esta casilla no se puede edificar (tipo: " + tipo + ").");
            return;
        }
        Solar s = (Solar) c;
        Grupo grupo = s.getGrupo();
        if (s.getDuenho() != jugador) {
            consola.imprimir("Esta casilla tiene otra dueño.");
            return;
        }
        if(!grupo.esDuenhoGrupo(jugador)){
            consola.imprimir("El jugador no es duenho de todo el grupo");
            return;
        }
        if(s.estaHipotecada()){
            consola.imprimir("No se puede edificar en una propiedad hipotecada.");
            return;
        }
        switch (tipoE) {
            case "casa":
                Casa casa = new Casa();
                casa.construir_casa(jugador, s);
                break;
            case "hotel":
                Hotel hotel = new Hotel();
                hotel.construir_hotel(jugador, s);
                break;
            case "piscina":
                Piscina piscina = new Piscina();
                piscina.construir_piscina(jugador, s);
                break;
            case "pista":
                Pista pista = new Pista();
                pista.construir_pista(jugador, s);
                break;
            default:
                consola.imprimir("Tipo de edificio no reconocido: " + tipoEdificio);
                break;
        }


    }

    @Override
    public void construirEdificio(String tipoEdificio){

        construirEdificioImpl(tipoEdificio);
    }

    //Método que ejecuta todas las acciones relacionadas con el comando 'salir carcel'.
    private void salirCarcelImpl() {
        if (jugadores == null || jugadores.isEmpty()) {
            consola.imprimir("No hay jugadores en la partida.");
            return;
        }
        Jugador jugadorActual = jugadores.get(turno);
        if (jugadorActual == null) {
            consola.imprimir("Error: jugador no encontrado.");
            return;
        }
        if (!jugadorActual.isEnCarcel()) {
            consola.imprimir("El jugador " + jugadorActual.getNombre() + " no está en la cárcel.");
            return;
        }
        float fianza = 500000f; // Valor fijo de la fianza
        if (jugadorActual.getFortuna() < fianza) {
            consola.imprimir("El jugador " + jugadorActual.getNombre() + " no tiene suficiente fortuna para pagar la fianza.");
            return;
        }
        jugadorActual.pagar(fianza, banca);
        jugadorActual.
                setEnCarcel(false);
        consola.imprimir("El jugador " + jugadorActual.getNombre() + " ha pagado la fianza de " + (int)fianza + "€ y ha salido de la cárcel. ");
        consola.imprimir("Fortuna restante: " + (int)jugadorActual.getFortuna() + "€.");
    }

    @Override
    public void salirCarcel(){
        salirCarcelImpl();
    }

    // Método que realiza las acciones asociadas al comando 'listar enventa'.
    private void listarVentaImpl () {
        if (tablero == null) {
            consola.imprimir("No hay tablero inicializado.");
            return;
        }
        java.util.List<Casilla> props = tablero.getPropiedadesEnVenta();
        if (props == null || props.isEmpty()) {
            consola.imprimir("No hay propiedades en venta.");
            return;
        }
        for (Casilla c : props) {
            String tipo = c.getTipo() == null ? "" : c.getTipo().toLowerCase();
            Propiedad p= (Propiedad) c;
            consola.imprimir("{");
            if ("solar".equals(tipo) || "transporte".equals(tipo) || "servicio".equals(tipo)) {
                consola.imprimir("nombre: " + c.getNombre() + ",");
            }
            consola.imprimir("tipo: " + tipo + ",");
            if ("solar".equals(tipo)) {
                Solar s= (Solar) c;
                String grupo = (s.getGrupo() != null && s.getGrupo().getColor() != null) ? getNombreColorGrupo(s.getGrupo().getColor()) : "sin grupo";
                consola.imprimir("grupo: " + grupo + ",");
            }
            consola.imprimir("valor: " + (int)p.getValor() + ",");
            consola.imprimir("},");
        }

    }

    @Override
    public void listarVenta(){
        listarVentaImpl();
    }

    // Método que realiza las acciones asociadas al comando 'listar jugadores'.
    private void listarJugadoresImpl () {
        if (jugadores == null || jugadores.isEmpty()) {
            consola.imprimir("No hay jugadores en la partida.");
            return;
        }

        for (Jugador jugador : jugadores) {
            if (jugador == null) continue;
            describirJugador(jugador.getNombre());
        }

    }
    @Override
    public void listarJugadores(){
        listarJugadoresImpl();
    }



    // Metodo que realiza las acciones asociadad al comando 'estadisticas <nombreJugador>'

    private void mostrarEstadisticasJugadorImpl(String nombreJugador) {
        if (jugadores == null || jugadores.isEmpty()) {
            consola.imprimir("No hay jugadores en la partida.");
            return;
        }

        Jugador j = null;
        for (Jugador jugador : jugadores) {
            if (jugador.getNombre().equalsIgnoreCase(nombreJugador)) {
                j = jugador;
                break;
            }
        }

        if (j == null) {
            consola.imprimir("No existe el jugador: " + nombreJugador);
            return;
        }

        consola.imprimir("{");
        consola.imprimir("dineroInvertido: "           + (int) j.getDineroInvertido() + ",");
        consola.imprimir("pagoTasasEImpuestos: "       + (int) j.getPagoDeTasasEImpuestos() + ",");
        consola.imprimir("pagoDeAlquileres: "          + (int) j.getPagoDeAlquileres() + ",");
        consola.imprimir("cobroDeAlquileres: "         + (int) j.getCobroDeAlquileres() + ",");
        consola.imprimir("pasarPorCasillaDeSalida: "   + (int) j.getDineroTotalPorPasarPorCasilla() + ",");
        consola.imprimir("premios,Inversiones,Bote: "   + (int) j.getPremios() + ",");
        consola.imprimir("vecesEnLaCarcel: "           +  j.getVecesEnCarcel());
        consola.imprimir("}");
    }

    @Override
    public void mostrarEstadisticasJugador(String nombreJugador){
        mostrarEstadisticasJugadorImpl(nombreJugador);
    }

    // Metodo que realiza las acciones asociadad al comando 'estadisticas' del juego

    private void estadisticasJuegoImpl() {
        if (jugadores == null || jugadores.isEmpty()) {
            consola.imprimir("No hay jugadores en la partida.");
            return;
        }

        // Variables para cálculos
        String casillaMasRentable = null;
        float maxRentable = -1f; // empieza en -1 para detectar si hay alguna rentable
        String grupoMasRentable = null;
        float maxGrupoRentable = -1f;
        String casillaMasFrecuentada = null;
        int maxFrecuentada = -1;
        String jugadorMasVueltas = null;
        int maxVueltas = -1;
        String jugadorEnCabeza = null;
        float maxFortuna = -1f;

        // Iterar sobre todas las casillas
        for (Casilla c : tablero.getTodasCasillas()) {
            if (c == null) continue;

            // monopoly.casilla.Casilla más frecuentada
            int numEstancias = c.getEstancias();
            if (numEstancias > maxFrecuentada) {
                maxFrecuentada = numEstancias;
                casillaMasFrecuentada = c.getNombre();
            }

            // monopoly.casilla.Casilla más rentable (solo solares con dueño)
            if ("solar".equalsIgnoreCase(c.getTipo())){
                Solar s= (Solar) c;
                if(s.getDuenho() != null) {
                    float alquilerTotal = s.calcularAlquiler();
                    if (alquilerTotal > maxRentable) {
                        maxRentable = alquilerTotal;
                        casillaMasRentable = c.getNombre();
                    }
                }
            }
        }

        // Grupo más rentable
        for (Grupo g : tablero.getGrupos()) {
            if (g == null) continue;
            float alquilerGrupo = 0f;
            boolean tienePropiedad = false;
            for (Casilla c : g.getMiembros()) {
                if (c != null && "solar".equalsIgnoreCase(c.getTipo())){
                    Solar s= (Solar) c;
                    if(s.getDuenho() != null) {
                        alquilerGrupo += s.calcularAlquiler();
                        tienePropiedad = true;
                    }
                }
            }
            if (tienePropiedad && alquilerGrupo > maxGrupoRentable) {
                maxGrupoRentable = alquilerGrupo;
                grupoMasRentable = getNombreColorGrupo(g.getColor());
            }
        }

        // Iterar sobre jugadores
        for (Jugador j : jugadores) {
            if (j == null) continue;

            int vueltas = j.getVueltas();
            if (vueltas > maxVueltas) {
                maxVueltas = vueltas;
                jugadorMasVueltas = j.getNombre();
            }

            float fortunaTotal = j.getFortuna();
            for (Casilla c : j.getPropiedades()) {
                if (c != null) {
                    Propiedad p = (Propiedad) c;
                    fortunaTotal += p.getValor();
                    if(p instanceof Solar) {
                    Solar s= (Solar) p;
                    if (s.getEdificios() != null) {
                        for (Edificio e : s.getEdificios()) {
                            if (e != null) fortunaTotal += e.getCoste();
                          }
                        }
                    }
                }
            }

            if (fortunaTotal > maxFortuna) {
                maxFortuna = fortunaTotal;
                jugadorEnCabeza = j.getNombre();
            }
        }

        consola.imprimir("{");
        consola.imprimir("casillaMasRentable: " +
                (casillaMasRentable != null ? casillaMasRentable + " (alquiler total: " + (int) maxRentable + "€)" : "N/A"));
        consola.imprimir("grupoMasRentable: " +
                (grupoMasRentable != null ? grupoMasRentable + " (alquiler total: " + (int) maxGrupoRentable + "€)" : "N/A"));
        consola.imprimir("casillaMasFrecuentada: " +
                (casillaMasFrecuentada != null ? casillaMasFrecuentada + " (veces visitada: " + maxFrecuentada + ")" : "N/A"));
        consola.imprimir("jugadorMasVueltas: " +
                (jugadorMasVueltas != null ? jugadorMasVueltas + " (vueltas: " + maxVueltas + ")" : "N/A"));
        consola.imprimir("jugadorEnCabeza: " +
                (jugadorEnCabeza != null ? jugadorEnCabeza + " (fortuna: " + (int) maxFortuna + "€)" : "N/A"));
        consola.imprimir("}");
    }
    @Override
    public void estadisticasJuego(){
        estadisticasJuegoImpl();
    }

    // Metodo que realiza las acciones asociadad al comando 'listar edificios'
    private void listarEdificiosImpl () {
        ArrayList<Edificio> edificios = new ArrayList<>();
        try {
            for (Casilla c : tablero.getTodasCasillas()) {
                if (c != null) {
                    Solar s= (Solar) c;
                    ArrayList<Edificio> edificiosC = s.getEdificios();
                    for (Edificio ed : edificiosC) {
                        edificios.add(ed);
                    }
                }
            }
        } catch (Exception ignore) {}
        for( Edificio e: edificios){
            consola.imprimir("{");
            consola.imprimir(" id: " + e.getId() + ",");
            consola.imprimir(" propietario: " + e.getPropietario().getNombre() + "," );
            consola.imprimir(" casilla: " + e.getCasilla().getNombre() + "," );
            consola.imprimir(" grupo: " + getNombreColorGrupo(e.getCasilla().getGrupo().getColor()) + ",");
            consola.imprimir(" coste: " + e.getCoste() + ",");
            consola.imprimir("}");
        }
    }
    @Override
    public void listarEdificios(){
        listarEdificiosImpl();
    }

    // Metodo que realiza las acciones asociadad al comando 'listar edificios'
// java
    private void listarEdificiosGrupoImpl (String colorGrupo) {
        if (tablero == null || tablero.getTodasCasillas() == null) {
            consola.imprimir("No hay tablero o casillas disponibles.");
            return;
        }
        if (colorGrupo == null) {
            consola.imprimir("Falta color de grupo.");
            return;
        }

        ArrayList<Casilla> casillasGrupo = new ArrayList<>();
        for (Casilla c : tablero.getTodasCasillas()) {
            if (c == null) continue;
            String tipo = c.getTipo();
            if (tipo == null || !"solar".equalsIgnoreCase(tipo)) continue;
            Solar s = (Solar) c;
            Grupo g = null;
            try {
                g = s.getGrupo();
            } catch (Throwable ignored) {}
            String nombreColor = (g != null && g.getColor() != null) ? getNombreColorGrupo(g.getColor()) : "sin grupo";
            if (colorGrupo.equalsIgnoreCase(nombreColor)) {
                casillasGrupo.add(c);
            }
        }

        if (casillasGrupo.isEmpty()) {
            consola.imprimir("No hay propiedades en el grupo " + colorGrupo + ".");
            return;
        }

        for (Casilla c : casillasGrupo) {
            Solar s= (Solar) c;
            ArrayList<String> casas = new ArrayList<>();
            ArrayList<String> hoteles = new ArrayList<>();
            ArrayList<String> piscinas = new ArrayList<>();
            ArrayList<String> pistas = new ArrayList<>();
            float alquiler = 0;
            ArrayList<Edificio> edificios = s.getEdificios();
            if (edificios != null) {
                for (Edificio e : edificios) {
                    if (e == null || e.getTipo() == null) continue;
                    switch (e.getTipo().toLowerCase()) {
                        case "casa": casas.add(e.getId()); break;
                        case "hotel": hoteles.add(e.getId()); break;
                        case "piscina": piscinas.add(e.getId()); break;
                        case "pista": pistas.add(e.getId()); break;
                    }
                }
            }
            alquiler = s.calcularAlquiler() - s.getImpuesto();
            consola.imprimir("{");
            consola.imprimir(" Propiedad: " + c.getNombre() + ",");
            consola.imprimir(" Casas: " + (casas.isEmpty() ? "-" : "[" + String.join(", ", casas) + "]"));
            consola.imprimir(" Hoteles: " + (hoteles.isEmpty() ? "-" : "[" + String.join(", ", hoteles) + "]"));
            consola.imprimir(" Piscinas: " + (piscinas.isEmpty() ? "-" : "[" + String.join(", ", piscinas) + "]"));
            consola.imprimir(" Pistas: " + (pistas.isEmpty() ? "-" : "[" + String.join(", ", pistas) + "]"));
            consola.imprimir(" Alquiler: " + alquiler);
            consola.imprimir("}");
        }
    }
    @Override
    public void listarEdificiosGrupo(String colorGrupo){
        listarEdificiosGrupoImpl(colorGrupo);
    }



    // Metodo que realiza las acciones sasociada al comando 'hipotecar'.

    private void hipotecarImpl (String nombreCasilla) {
        if (jugadores == null || jugadores.isEmpty()) {
            consola.imprimir("No hay jugadores en la partida.");
            return;
        }
        Jugador j = jugadores.get(turno);
        if (j == null){
            consola.imprimir("Error: jugador no encontrado.");
            return;
        }
        Casilla c = tablero.encontrar_casilla(nombreCasilla);
        if (c == null) {
            consola.imprimir("No existe la casilla: " + nombreCasilla);
            return;
        }
        String tipo = c.getTipo();
        if (!tipo.equals("Solar")) {
            consola.imprimir("Esta casilla no se puede hipotecar, debe ser un solar (tipo: " + tipo + ").");
            return;
        }
        Solar s = (Solar) c;
        if (s.getDuenho() != j) {
            consola.imprimir("Esta casilla tiene otro dueño.");
            return;
        }
        if (s.estaHipotecada()) {
            consola.imprimir("Esta casilla ya está hipotecada.");
            return;
        }
        if (s.getEdificios().isEmpty()){
            consola.imprimir("No se puede hipotecar " + nombreCasilla + " porque tiene edificios construidos. Vendelos primero si quieres hipotecar.");
            return;
        }

        s.setHipotecaAuto();
        j.recibir(s.getHipoteca());
        consola.imprimir(j.getNombre() + " recibe "+  s.getHipoteca() + "€ por la hipoteca de " + nombreCasilla + ". No puede recibir alquileres ni edificar en el grupo " + getNombreColorGrupo(s.getGrupo().getColor()) + ".");
    }
    @Override
    public void hipotecar(String nombreCasilla){
        hipotecarImpl(nombreCasilla);
    }

    private void deshipotecarImpl (String nombreCasilla){
        if (jugadores == null || jugadores.isEmpty()) {
            consola.imprimir("No hay jugadores en la partida.");
            return;
        }

        Jugador j = jugadores.get(turno);
        if (j == null){
            consola.imprimir("Error: jugador no encontrado.");
            return;
        }

        Casilla c = tablero.encontrar_casilla(nombreCasilla);
        if (c == null) {
            consola.imprimir("No existe la casilla: " + nombreCasilla);
            return;
        }
        String tipo = c.getTipo();
        if (!tipo.equals("Solar")) {
            consola.imprimir("Esta casilla no se puede hipotecar, debe ser un solar (tipo: " + tipo + ").");
            return;
        }
        Solar s = (Solar) c;

        if (s.getDuenho() != j) {
            consola.imprimir("Esta casilla tiene otro dueño.");
            return;
        }

        if (!s.estaHipotecada()) {
            consola.imprimir(j.getNombre() + " no puede deshipotecar " + nombreCasilla + ". No está hipotecada.");
            return;
        }
        float coste=s.getHipoteca();
        if (coste <= 0) coste = s.getValor() / 2f;
        if (j.getFortuna() < coste) {
            consola.imprimir(j.getNombre() + " no tiene suficiente fortuna para deshipotecar " + nombreCasilla + " (necesita " + (int)coste + "€, tiene " + (int)j.getFortuna() + "€).");
            return;
        }

        //pagar y limpiar hipoteca
        j.pagar(coste, banca);
        s.setHipoteca(0f);

        String colorGrupo = (s.getGrupo() != null && s.getGrupo().getColor() != null) ? getNombreColorGrupo(s.getGrupo().getColor()) : "sin grupo";

        consola.imprimir(j.getNombre() + " paga " + (int)coste + "€ por deshipotecar " + nombreCasilla + ". Ahora puede recibir alquileres y edificar en el grupo " + colorGrupo + ".");


    }
    @Override
    public void deshipotecar(String nombreCasilla){
        deshipotecarImpl(nombreCasilla);
    }

    public void venderEdificiosImpl(String tipoEdificio, String nombreCasilla, int numero){
        if (jugadores == null || jugadores.isEmpty()) {
            consola.imprimir("No hay jugadores en la partida.");
            return;
        }

        Jugador j = jugadores.get(turno);
        if (j == null){
            consola.imprimir("Error: jugador no encontrado.");
            return;
        }

        Casilla c = tablero.encontrar_casilla(nombreCasilla);
        if (c == null) {
            consola.imprimir("No existe la casilla: " + nombreCasilla);
            return;
        }
        String tipo = c.getTipo();
        if (!tipo.equals("Solar")) {
            consola.imprimir("Esta casilla no se pueden tener edificios, debe ser un solar (La tuya es tipo: " + tipo + ").");
            return;
        }
        Solar s = (Solar) c;
        if (s.getDuenho() != j) {
            consola.imprimir("Esta casilla tiene otro dueño.");
            return;
        }
        if(s.estaHipotecada()){
            consola.imprimir("No se puede vender edificios en una propiedad hipotecada.");
            return;
        }
        if (s.getEdificios().isEmpty()){
            consola.imprimir("No hay edificios en esta casilla para vender.");
            return;
        }
        ArrayList<Edificio> edificios = s.getEdificios();
        float ganancia = 0f;
        switch(tipoEdificio){
            case "casa":
            case "casas":
                if(s.getNumCasas()<= 0) {
                    consola.imprimir("No tienes casas construidas en esta propiedad.");
                    return;
                }
                int casasBorrar = s.getNumCasas() - numero;
                if(!s.setNumCasas(casasBorrar)){
                    return;
                }
                int numeroBorrar = numero;
                while(numeroBorrar > 0) {
                    for (Edificio e : edificios) {
                        if (e.getTipo().equals("casa")) {
                            ganancia = ganancia + e.getCoste();
                            numeroBorrar--;
                        }
                    }
                }
                j.recibir(ganancia);
                consola.imprimir( j.getNombre() + " ha vendido " + numero + " casas en " + c.getNombre() + ", recibiendo " + ganancia + "€. En la propiedad quedan " + s.getNumCasas() +  " casas.");
                break;
            case "hotel":
            case "hoteles":
                if(s.getNumHoteles() != 1) {
                    consola.imprimir("No tienes hoteles construidos en esta propiedad.");
                    return;
                }
                if (s.getNumPistas() == 1 || s.getNumPiscinas() == 1){
                    consola.imprimir("No puedes vender un hotel si tienes una pista o psicina construida. Vendelas primero.");
                    return;
                }
                if(numero == 1){
                    s.eliminarHotel();
                    for (Edificio e : edificios) {
                        if (e.getTipo().equals("hotel")) {
                            ganancia = ganancia + e.getCoste();
                        }
                    }
                    j.recibir(ganancia);
                    consola.imprimir( j.getNombre() + " ha vendido un hotel en  " + c.getNombre() + ", recibiendo " + ganancia + "€.");
                } else{
                    consola.imprimir("Solo puedes vender un hotel.");
                    return;
                }
                break;
            case "piscina":
            case "piscinas":
                if(s.getNumPiscinas() != 1) {
                    consola.imprimir("No tienes piscinas construidas en esta propiedad.");
                    return;
                }
                if(s.getNumPistas() == 1){
                    consola.imprimir("No puedes vender una piscina si tienes una pista construida. Vendela primero.");
                    return;
                }
                if(numero == 1){
                    s.eliminarPiscina();
                    for (Edificio e : edificios) {
                        if (e.getTipo().equals("piscina")) {
                            ganancia = ganancia + e.getCoste();
                        }
                    }
                    j.recibir(ganancia);
                    consola.imprimir( j.getNombre() + " ha vendido una piscina en  " + c.getNombre() + ", recibiendo " + ganancia + "€.");
                } else{
                    consola.imprimir("Solo puedes vender una piscina.");
                    return;
                }
                break;
            case "pista":
            case "pistas":
                if(s.getNumPistas() != 1) {
                    consola.imprimir("No tienes pistas construidas en esta propiedad.");
                    return;
                }
                if(numero == 1){
                    s.eliminarPista();
                    for (Edificio e : edificios) {
                        if (e.getTipo().equals("pista")) {
                            ganancia = ganancia + e.getCoste();
                        }
                    }
                    j.recibir(ganancia);
                    consola.imprimir( j.getNombre() + " ha vendido una pista en  " + c.getNombre() + ", recibiendo " + ganancia + "€.");
                } else{
                    consola.imprimir("Solo puedes vender una pista.");
                    return;
                }
                break;
        }

    }

    @Override
    public void venderEdificios(String tipoEdificio, String nombreCasilla, int numero){
        venderEdificiosImpl(tipoEdificio, nombreCasilla, numero);
    }

    // Método que realiza las acciones asociadas al comando 'acabar turno'.
    private void acabarTurnoImpl () {
        if (jugadores == null || jugadores.isEmpty()) {
            consola.imprimir("No hay jugadores en la partida.");
            return;
        }
        lanzamientos = 0;
        tirado = false;
        solvente = true;
        int n = jugadores.size();
        if (n == 0) {
            consola.imprimir("No hay jugadores");
            return;
        }
        int next = (turno + 1) % n;
        int intentos = 0;
        while (intentos < n) {
            Jugador candidato = jugadores.get(next);
            // Se asume que existe getFortuna() y >0 significa que puede jugar
            if (candidato != null && candidato.getFortuna() > 0) {
                turno = next;
                consola.imprimir("Turno de: " + candidato.getNombre() + " (avatar: " + (candidato.getAvatar() != null ? candidato.getAvatar().getId() : "sin avatar") + ")");
                return;
            }
            next = (next + 1) % n;
            intentos++;
        }
        consola.imprimir("No hay jugadores solventes para continuar la partida.");
    }
    @Override
    public void acabarTurno(){
        acabarTurnoImpl();
    }

    private void crearJugadorImpl(String nombre, String tipoAvatar) {
        ArrayList<Avatar> avCreados = new ArrayList<>();
        Jugador nuevo = new Jugador(nombre, tipoAvatar, tablero.encontrar_casilla("Salida"), avCreados);
        jugadores.add(nuevo);

        consola.imprimir("{");
        consola.imprimir(" nombre: " + nombre + ",");
        consola.imprimir(" avatar: " + (nuevo.getAvatar() != null ? nuevo.getAvatar().getId() : "sin avatar"));
        consola.imprimir("}");
        consola.imprimir(tablero.toString());
    }
    @Override
    public void crearJugador(String nombre, String tipoAvatar){
        crearJugadorImpl(nombre, tipoAvatar);
    }


    // Mostrar el jugador cuyo turno es
    private void mostrarTurnoImpl() {
        if (jugadores.isEmpty()) return;
        Jugador jugador = jugadores.get(turno);
        consola.imprimir("{");
        consola.imprimir(" nombre: " + jugador.getNombre() + ",");
        consola.imprimir(" avatar: " + (jugador.getAvatar() != null ? jugador.getAvatar().getId() : "sin avatar"));
        consola.imprimir("}");
    }
    @Override
    public void mostrarTurno(){
        mostrarTurnoImpl();
    }

    private String getNombreColorGrupo(String color) {
        if (color == null) return "sin grupo";
        color = color.trim().toLowerCase();
        if (color.contains("[31m") || color.equals("\u001B[31m") || color.equals("rojo")) {
            return "rojo";
        } else if (color.contains("[34m") || color.equals("\u001B[34m") || color.equals("azul")) {
            return "azul";
        } else if (color.contains("[32m") || color.equals("\u001B[32m") || color.equals("verde")) {
            return "verde";
        } else if (color.contains("[33m") || color.equals("\u001B[33m") || color.equals("amarillo")) {
            return "amarillo";
        } else if (color.contains("[35m") || color.equals("\u001B[35m") || color.equals("morado")) {
            return "morado";
        } else if (color.contains("[36m") || color.equals("\u001B[36m") || color.equals("cyan")) {
            return "cyan";
        } else if (color.contains("[38;2;150;75;0m")) {
            return "marron";
        } else if (color.contains("[30m") || color.equals("\u001B[30m")) {
            return "negrita";
        } else {
            return color;
        }
    }
}