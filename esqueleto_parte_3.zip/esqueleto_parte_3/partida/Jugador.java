package partida;

import java.util.ArrayList;

import monopoly.casilla.Casilla;
import monopoly.casilla.propiedad.Propiedad;
import monopoly.casilla.propiedad.Solar;
import monopoly.edificios.Edificio;
import static monopoly.Juego.consola;

public class Jugador {

    //Atributos:
    private String nombre; //Nombre del jugador
    private Avatar avatar; //Avatar que tiene en la partida.
    private float fortuna; //Dinero que posee.
    private float gastos; //Gastos realizados a lo largo del juego.
    private boolean enCarcel; //Será true si el jugador está en la carcel
    private int tiradasCarcel; //Cuando está en la carcel, contará las tiradas sin éxito que ha hecho allí para intentar salir (se usa para limitar el numero de intentos).
    private int vueltas; //Cuenta las vueltas dadas al tablero.
    private ArrayList<Propiedad> propiedades; //Propiedades que posee el jugador.
    private Casilla lugar;
    private boolean bancarrota = false;
    private int VecesEnCarcel;
    private float DineroPorPasarPorSalida;
    private float CobroDeAlquileres;
    private float PagoDeAlquileres;
    private float PagoDeTasasEImpuestos;
    private float DineroInvertido;
    private float Premios;


    //Constructor vacío. Se usará para crear la banca.
    public Jugador() {
    }


    /*Constructor principal. Requiere parámetros:
     * Nombre del jugador, tipo del avatar que tendrá, casilla en la que empezará y ArrayList de
     * avatares creados (usado para dos propósitos: evitar que dos jugadores tengan el mismo nombre y
     * que dos avatares tengan mismo ID). Desde este constructor también se crea el avatar.
     */
    public Jugador(String nombre, String tipoAvatar, Casilla inicio, ArrayList<Avatar> avCreados) {
        boolean nombreValido = true;
        if(avCreados!=null){
            for(Avatar a:avCreados){
                if(a!=null && a.getJugador()!=null){
                    String nombreAv = a.getJugador().getNombre();
                    if(nombreAv!= null && nombreAv.equalsIgnoreCase(nombre)){
                        consola.imprimir("Jugador existente");
                        nombreValido = false;
                    }
                }
            }
        }
        if(nombreValido){
            this.nombre = nombre;
            this.avatar = new Avatar(tipoAvatar,this,inicio,avCreados);
            this.fortuna = 15_000_000f;
            this.gastos = 0f;
            this.enCarcel = false;
            this.tiradasCarcel = 0;
            this.vueltas = 0;
            this.propiedades = new ArrayList<>();
            this.lugar = inicio;
        }

    }

    //Otros métodos:
    //Método para añadir una propiedad al jugador. Como parámetro, la casilla a añadir.
    public void anhadirPropiedad(Propiedad casilla) {
        if (!propiedades.contains(casilla)) {
            propiedades.add(casilla);
        }
    }

    //Método para eliminar una propiedad del arraylist de propiedades de jugador.
    public void eliminarPropiedad(Casilla casilla) {
        propiedades.remove(casilla);
    }

    //Método para añadir fortuna a un jugador
    //Como parámetro se pide el valor a añadir. Si hay que restar fortuna, se pasaría un valor negativo.
    public void sumarFortuna(float valor) {
        this.fortuna += valor;
    }
    //Método para sumar gastos a un jugador.
    //Parámetro: valor a añadir a los gastos del jugador (será el precio de un solar, impuestos pagados...).
    public void sumarGastos(float valor) {
        this.gastos += valor;
    }
    public void pagar(float cantidad, Jugador destinatario) {
        if (fortuna >= cantidad) {
            fortuna -= cantidad;
            sumarGastos(cantidad);
            destinatario.recibir(cantidad);
        }
    }
    public int pagarBanca(float cantidad) {
        if (fortuna >= cantidad) {
            fortuna -= cantidad;
            sumarGastos(cantidad);
            return 0; // Pago exitoso
        }
        else return 1;
    }
    public void recibir(float cantidad) {

        this.fortuna += cantidad;
    }

    public boolean puedePagar(float cantidad) {

        return this.fortuna >= cantidad;
    }

    public boolean isBancarrota() {

        return bancarrota;
    }


    public void declararBancarrota(Jugador acreedor) {
        for (Propiedad propiedad : propiedades) {
            propiedad.setDuenho(acreedor);
            acreedor.anhadirPropiedad(propiedad);
            if(propiedad.getTipo().equalsIgnoreCase("Solar")){
                Solar propiedadS = (Solar) propiedad;
                for (Edificio edificio : propiedadS.getEdificios()) {
                    edificio.setPropietario(acreedor);
                }
            }
        }
        this.propiedades.clear();
        this.fortuna = 0;
        this.bancarrota = true;
        consola.imprimir(this.nombre + " ha declarado bancarrota.");
    }

    public int contarServicios() {
        int contador = 0;
        for (Casilla propiedad : propiedades) {
            if ("Servicios".equalsIgnoreCase(propiedad.getTipo())) {
                contador++;
            }
        }
        return contador;
    }
    public int contarTransportes() {
        int contador = 0;
        for (Casilla propiedad : propiedades) {
            if ("Transporte".equalsIgnoreCase(propiedad.getTipo())) {
                contador++;
            }
        }
        return contador;
    }

    /*Método para establecer al jugador en la cárcel.
     * Se requiere disponer de las casillas del tablero para ello (por eso se pasan como parámetro).*/
    public void encarcelar(ArrayList<ArrayList<Casilla>> casillasTablero) {
        for (ArrayList<Casilla> lado : casillasTablero) {
            for (Casilla casilla : lado) {
                if (casilla.getNombre().equalsIgnoreCase("Carcel")) {
                    this.lugar = casilla;
                    this.enCarcel = true;
                    return;
                }
            }
        }
    }


    public String getNombre(){
        return nombre;
    }
    public Avatar getAvatar(){
        return avatar;
    }
    public float getFortuna(){
        return fortuna;
    }
    public float getGastos(){
        return gastos;
    }
    public boolean isEnCarcel(){
        return enCarcel;
    }
    public int getTiradasCarcel(){
        return tiradasCarcel;
    }
    public int getVueltas(){
        return vueltas;
    }
    public ArrayList<Propiedad> getPropiedades(){
        return propiedades;
    }
    public int getVecesEnCarcel() { return VecesEnCarcel;}
    public float getDineroTotalPorPasarPorCasilla() { return DineroPorPasarPorSalida;}
    public float getPagoDeAlquileres(){ return PagoDeAlquileres; }
    public float getCobroDeAlquileres(){ return CobroDeAlquileres; }
    public float getDineroInvertido(){return DineroInvertido;}
    public float getPagoDeTasasEImpuestos(){ return PagoDeTasasEImpuestos;}
    public float getPremios(){ return Premios;}

    public void sumarTiradasCarcel() {
        this.tiradasCarcel++;
    }
    public void resetTiradasCarcel() {
        this.tiradasCarcel = 0;
    }
    public void setEnCarcel(boolean enCarcel) {
        this.enCarcel = enCarcel;
        if (!enCarcel) {
            this.tiradasCarcel = 0;
        }
    }
    public void sumarVueltas() {
        this.vueltas++;
    }
    public void setFortuna(float fortuna) {
        this.fortuna = fortuna;
    }
    public void setLugar(Casilla lugar) {
        this.lugar = lugar;
    }
    public void setVecesEnCarcel (){  this.VecesEnCarcel ++;}
    public void sumarDineroVecesSalida (float cantidad){ this.DineroPorPasarPorSalida += cantidad ;}
    public void setPagoDeAlquileres( float PagoDeAlquileres){this.PagoDeAlquileres += PagoDeAlquileres;}
    public void setCobroDeAlquileres( float CobroDeAlquileres){ this.CobroDeAlquileres += CobroDeAlquileres;  }
    public void setDineroInvertido(float DineroInvertido){ this.DineroInvertido += DineroInvertido;  }
    public void setPagoDeTasasEImpuestos(float PagoDeTasasEImpuestos){ this.PagoDeTasasEImpuestos += PagoDeTasasEImpuestos;  }
    public void setPremios(float Premios){ this.Premios += Premios;  }
}