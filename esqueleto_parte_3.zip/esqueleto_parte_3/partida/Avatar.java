package partida;

import monopoly.*;
import monopoly.casilla.Casilla;
import static monopoly.Juego.consola;

import java.util.ArrayList;


public class Avatar {

    //Atributos
    private String id; //Identificador: una letra generada aleatoriamente.
    private String tipo; //Sombrero, Esfinge, Pelota, Coche
    private Jugador jugador; //Un jugador al que pertenece ese avatar.
    private Casilla lugar; //Los avatares se sitúan en casillas del tablero.

    //Constructor vacío
    public Avatar() {
    }

    /*Constructor principal. Requiere éstos parámetros:
     * Tipo del avatar, jugador al que pertenece, lugar en el que estará ubicado, y un arraylist con los
     * avatares creados (usado para crear un ID distinto del de los demás avatares).
     */
    public Avatar(String tipo, Jugador jugador, Casilla lugar, ArrayList<Avatar> avCreados) {
        this.tipo = tipo;
        this.jugador = jugador;
        this.lugar = lugar;
        //generamos una letra no usada
        generarId(avCreados);
        //metemos el avatar en la lista de avatares creados
        if(avCreados != null){
            avCreados.add(this);// Añade el avatar a la lista
        }
        // añade el avatar a la lista de avatares de la casilla
        if (this.lugar != null) {
            this.lugar.anhadirAvatar(this);
        }
    }

    //A continuación, tenemos otros métodos útiles para el desarrollo del juego.
    /*Método que permite mover a un avatar a una casilla concreta. Parámetros:
     * - Un array con las casillas del tablero. Se trata de un arrayList de arrayList de casillas (uno por lado).
     * - Un entero que indica el numero de casillas a moverse (será el valor sacado en la tirada de los dados).
     * EN ESTA VERSIÓN SUPONEMOS QUE valorTirada siemrpe es positivo.
     */
    public void moverAvatar(ArrayList<ArrayList<Casilla>> casillas, int valorTirada) {
        // Construir lista lineal sin repeticiones
        ArrayList<Casilla> recorrido = new ArrayList<>();
        for (int i = 0; i < casillas.size(); i++) {
            for (Casilla c : casillas.get(i)) {
                if (!recorrido.contains(c)) {
                    recorrido.add(c);
                }
            }
        }
        // Buscar posición actual
        int posActual = recorrido.indexOf(this.lugar);
        if (posActual == -1) return; // No encontrada

        int posDestino = (posActual + valorTirada) % recorrido.size();

        // Detectar si pasa por Salida
        if (posDestino <= posActual && valorTirada > 0) {
            // Buscar la casilla "Salida"
            for (Casilla c : recorrido) {
                if (c.getNombre().equalsIgnoreCase("Salida")) {
                    this.getJugador().recibir(Valor.SUMA_VUELTA);
                    this.getJugador().sumarDineroVecesSalida(Valor.SUMA_VUELTA);
                    this.getJugador().sumarVueltas();
                    consola.imprimir(this.getJugador().getNombre() + " ha pasado por Salida y recibe " + (int)Valor.SUMA_VUELTA + "€.");
                    break;
                }
            }
        }
        //situa avatar en posicion destino
        setLugar(recorrido.get(posDestino));
    }


    /*Método que permite generar un ID para un avatar. Sólo lo usamos en esta clase (por ello es privado).
     * El ID generado será una letra mayúscula. Parámetros:
     * - Un arraylist de los avatares ya creados, con el objetivo de evitar que se generen dos ID iguales.
     */
    private void generarId(ArrayList<Avatar> avCreados) {
        String nuevoID= "";
        boolean repetido = true;

        while(repetido){
            //generamos letra entre A y Z
            char letra = (char) ( 'A' + (int)(Math.random()*26));
            nuevoID = String.valueOf(letra);
            //comprobamos si esta en la lista
            repetido = false;
            if(avCreados!= null){
                for( Avatar a : avCreados ){
                    if(a.getId().equals(nuevoID)){
                        repetido = true;
                        break;
                    }
                }
            }
        }
        //asignamos el id al avatar
        this.id = nuevoID;
    }

    //Getters y setters

    public String getId() { return id; }
    public String getTipo() { return tipo; }
    public Jugador getJugador() { return jugador; }
    public Casilla getLugar() { return lugar; }
    public void setLugar(Casilla lugar) {
        // eliminar del lugar anterior
        if (this.lugar != null) {
            this.lugar.eliminarAvatar(this);
        }
        // asignar y añadir al nuevo
        this.lugar = lugar;
        if (this.lugar != null) {
            this.lugar.anhadirAvatar(this);
        }
    }
}