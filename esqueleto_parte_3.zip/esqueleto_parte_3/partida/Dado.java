package partida;


import java.util.Random;

public class Dado {
    //El dado solo tiene un atributo en nuestro caso: su valor.
    private int valor;


    //Metodo para simular lanzamiento de un dado: devolverá un valor aleatorio entre 1 y 6.
    public int hacerTirada() {
        this.valor =  new Random().nextInt(6)+ 1;
        return valor;
    }

    // Método público para forzar una tirada
    public int forzarTirada(int valor) {
        if (valor < 1) valor = 1;
        if (valor > 6) valor = 6;
        this.valor = valor;
        return this.valor;
    }
    public void setValor(int valor) {
        this.valor = valor;
    }
    public int getValor() {
        return valor;
    }
    @Override
    public String toString() {
        return String.valueOf(valor);
    }
}
